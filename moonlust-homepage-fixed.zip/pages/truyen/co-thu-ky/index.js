export default function CoThuKy() {
  return (
    <div>
      <h2>📖 Cô Thư Ký – Giới thiệu</h2>
      <p>Một câu chuyện về giằng xé cảm xúc và đam mê bề kìm nén...</p>
      <a href="/truyen/co-thu-ky/chuong-1">Đọc Chương 1</a>
    </div>
  );
}
