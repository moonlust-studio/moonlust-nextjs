// pages/index.js
import Link from 'next/link';

export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>🌕 Moonlust</h1>
      <p>Truyện người lớn tinh tế – đầy nội tâm – đậm cảm xúc.</p>
      <ul>
        <li>
          <Link href="/truyen/co-thu-ky/chuong-1">📖 Cô Thư Ký – Chương 1</Link>
        </li>
      </ul>
    </div>
  );
}
