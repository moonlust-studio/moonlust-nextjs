// pages/truyen/co-thu-ky/chuong-1.js
export default function Chuong1() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Cô Thư Ký – Chương 1: Ánh Nhìn Đầu Tiên</h1>
      <p>Cô là một thư ký đã có chồng – thông minh, điềm đạm và rất ghét chuyện ngoại tình.</p>
      <p>Anh là vị sếp đã có vợ – thành đạt, lịch lãm và đầy bản lĩnh.</p>
      <p>Lần đầu tiên ánh mắt họ chạm nhau trong phòng họp, mọi thứ chỉ là công việc.</p>
      <p>Nhưng đêm đó – giữa ánh đèn mờ và nhịp tim thổn thức… không ai rút lại.</p>
    </div>
  );
}
