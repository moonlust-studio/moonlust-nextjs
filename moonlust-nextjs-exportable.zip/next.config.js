// next.config.js
const nextConfig = {
  output: 'export',
  reactStrictMode: true,
};
module.exports = nextConfig;
