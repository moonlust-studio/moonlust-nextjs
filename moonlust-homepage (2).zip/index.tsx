// moonlust-homepage/index.tsx

import Head from "next/head";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sun, Moon } from "lucide-react";

const translations: Record<string, any> = {
  vi: {
    headline: "Khơi dậy khát khao, chạm tới cảm xúc",
    subtitle: "Moonlust – Thế giới truyện người lớn gợi cảm, tinh tế và đầy mê hoặc",
    discover: "Khám phá ngay",
    featured: "🔥 Truyện nổi bật",
    category: "📚 Danh mục truyện",
    top: "📈 Truyện nhiều người đọc",
    all: "Tất cả",
    completed: "Hoàn thành",
    ongoing: "Chưa hoàn",
    metaTitle: "Moonlust - Thế giới truyện người lớn tinh tế",
    metaDesc: "Website đọc truyện người lớn gợi cảm, tinh tế, nội dung cuốn hút và quyến rũ.",
  },
  en: {
    headline: "Ignite desire, touch emotions",
    subtitle: "Moonlust – A world of sensual, elegant and captivating adult stories",
    discover: "Discover now",
    featured: "🔥 Featured Stories",
    category: "📚 Story Categories",
    top: "📈 Most Read Stories",
    all: "All",
    completed: "Completed",
    ongoing: "Ongoing",
    metaTitle: "Moonlust - Elegant Erotic Stories",
    metaDesc: "Read sensual, artistic adult fiction in a beautiful and discreet environment.",
  },
  jp: {
    headline: "欲望を呼び起こし、感情に触れる",
    subtitle: "Moonlust – セクシーで洗練された大人の物語の世界",
    discover: "今すぐ読む",
    featured: "🔥 注目のストーリー",
    category: "📚 ストリーカテゴリー",
    top: "📈 人気のストーリー",
    all: "すべて",
    completed: "完結",
    ongoing: "連載中",
    metaTitle: "Moonlust - 大人のための洗練された物語",
    metaDesc: "感情と欲望が交差する、洗練された官能的なストーリーをお楽しみください。",
  },
};

const stories = [
  {
    title: "Cô nàng thư ký",
    status: "Hoàn thành",
    chapters: 12,
    summary: "Một mối quan hệ đầy giằng xé giữa cô thư ký và người sếp đã có gia đình...",
    cover: "/images/thu-ky.jpg",
    hot: true,
    genre: "Ngoại tình",
    views: 5500,
  },
  {
    title: "Người tình mùa hè",
    status: "Đang cập nhật",
    chapters: 5,
    summary: "Tình yêu nảy nở giữa hai con người xa lạ trong chuyến nghỉ dưỡng biển...",
    cover: "/images/mua-he.jpg",
    hot: true,
    genre: "Lãng mạn",
    views: 4200,
  },
  {
    title: "Ký túc xá rực lửa",
    status: "Hoàn thành",
    chapters: 9,
    summary: "Những câu chuyện nóng bỏng đằng sau cánh cửa phòng KTX nữ...",
    cover: "/images/kytucxa.jpg",
    hot: false,
    genre: "Giới trẻ",
    views: 6800,
  },
];

export default function Home() {
  const [darkMode, setDarkMode] = useState(false);
  const [lang, setLang] = useState("vi");
  const [filter, setFilter] = useState("all");

  const t = translations[lang];

  const toggleDarkMode = () => setDarkMode(!darkMode);

  const filteredStories = stories.filter((s) =>
    filter === "all" ? true : s.status === filter
  );

  const hotStories = stories.filter((s) => s.hot);

  const topStories = [...stories].sort((a, b) => b.views - a.views).slice(0, 3);

  return (
    <>
      <Head>
        <title>{t.metaTitle}</title>
        <meta name="description" content={t.metaDesc} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta charSet="utf-8" />
        <html lang={lang} />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div
        className={
          (darkMode ? "bg-gray-900 text-white" : "bg-white text-black") +
          " min-h-screen font-sans transition-colors duration-300 ease-in-out scroll-smooth"
        }
      >
        <section className="py-16 px-6">
          <h2 className="text-4xl font-bold mb-4 transition-colors duration-300">
            {t.headline}
          </h2>
          <p className="text-lg mb-6 max-w-3xl leading-relaxed text-gray-600 dark:text-gray-300">
            {t.subtitle}
          </p>
          <Button className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-full transition-all duration-300 shadow-lg">
            {t.discover}
          </Button>
        </section>

        <section className="py-16 px-6">
          <h3 className="text-2xl font-semibold mb-8">{t.featured}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {hotStories.map((story, index) => (
              <Card
                key={index}
                className="overflow-hidden rounded-2xl shadow-md hover:shadow-xl transform hover:scale-[1.02] transition-all duration-300"
              >
                <img
                  src={story.cover}
                  alt={`Ảnh bìa truyện ${story.title}`}
                  className="h-48 w-full object-cover"
                />
                <CardContent className="p-4">
                  <h4 className="text-xl font-bold mb-2">{story.title}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                    {story.summary}
                  </p>
                  <p className="text-sm italic">
                    Số chương: {story.chapters} – {story.status}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}
