# Chapter 10 – Everything That Trembled Inside Her

📖 **Teaser:** When guilt begins to taste like desire, even silence burns.  
🎧 **Tagline:** Some lines, once crossed, redraw the shape of a woman’s soul.

---

The office bathed in the golden hush of late afternoon. Ha Anh leaned against the edge of her desk, the hem of her skirt brushing her thighs. She hadn’t meant to stay this late, but part of her didn’t want to go home either.

Her phone buzzed.

**Quan:**  
“Can you meet now? I’ve been thinking about nothing else.”

Her fingers hovered over the screen. The air in the room felt thicker, heavier, as if her hesitation had weight.

**“Give me ten minutes.”**

She didn’t look at herself before leaving. Didn’t fix her makeup. Didn’t rehearse what to say.  
She just walked.

---

Quan’s place smelled faintly of bergamot and whiskey. Ha Anh stood at the door, coat still on, heart pounding beneath layers of reason she no longer believed in.

Quan opened the door and stepped aside, silent. No words. Just breath, heat, and tension.  
The moment the door closed behind her, she turned—and kissed him.  
**Hard.**

As if every missed chance from the past had finally caught up and refused to be denied.

Her coat slid off her shoulders. His hands found her hips. Lips parted. Teeth grazed. Tongues met like fire meeting oil.

She dropped to her knees.

The carpet scraped her skin as she reached for his belt. Her fingers trembled—not from fear, but from need. From memory. From the echo of how he used to taste.

She looked up at him—eyes glinting with something wild, almost broken.  
Then, without a word, she took him into her mouth.

**Soft. Deep. Slow.**

Each stroke of her lips a confession. Each swirl of her tongue a surrender.

Quan let out a low groan, his hand tangled in her hair, not guiding—just grounding himself.  
She went deeper. Gagged. Pulled back. Went again.  
Until her tears mixed with spit and his moans became prayers.

When he came, she didn’t flinch. Just swallowed.  
And smiled.  
**“Missed that,”** she whispered, wiping her mouth with the back of her hand.

---

Later, he lay on the couch, still dazed. She straddled him—**facing away**.

**“Don’t you want to see me?”** he asked.

**“I want to feel you,”** she murmured, sinking down onto him.  
A sharp gasp escaped her lips.

Her hands gripped the backrest. Her hips rolled. Slowly at first—then faster. Desperate. Hungry.  
She rode him like memory, like vengeance, like she was trying to undo every year they’d lost.

Their bodies slapped, the sound wet and obscene and perfect.  
He reached around, cupped her breasts. She arched.

**“Say it,”** he rasped.  
**“That you ruined me?”** she breathed. **“That every night with him felt like a lie after you?”**

He thrust up, matching her rhythm.  
She came—shaking, panting, biting her lip to keep from screaming.  
He followed—face buried in her back, breath ragged.

---

Steam curled in the bathroom. Ha Anh stood under the water, letting it cascade down her flushed skin. Her legs still trembled.

Quan stepped behind her, arms circling her waist.  
**“I shouldn’t be here,”** she whispered.  
**“But you are.”**

He kissed her shoulder. Traced her spine.  
Hands found thighs. Lifted. Pressed.

He entered her from behind—**slow, steady**.  
Water splashed. Skin met skin.  
She moaned—high, soft, helpless.

His voice was a growl in her ear:  
**“Who makes you feel this alive?”**

She didn’t answer. Couldn’t.  
Her head fell back. He held her tighter.

Each thrust sent shockwaves up her spine, through her ribs, into the place that still remembered how to ache.

She came again—silently this time, mouth open in a scream she swallowed.  
When he followed, she felt every pulse, every twitch, every unspoken vow he poured into her.

---

Wrapped in towels, they lay on his bed. No words. Just breath syncing in the dark.

**“I’m not asking you to leave your life,”** he said. **“Just to be honest with yourself.”**

She turned to him.  
**“I don’t know who I am with you.”**  
**“Yes,”** he said gently. **“You do. You’ve just been pretending not to.”**

She looked up at the ceiling.  
And somewhere deep inside—**something crumbled.**
