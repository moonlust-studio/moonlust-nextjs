# Chapter 7 – When the Body Speaks

📖 **Teaser:** Some voices need no words. Just a look, a touch... and the body will answer on its own.

---

The phone had just gone silent, and Ha Anh stood frozen — both hands gripping the window ledge, her body locked between a tide of memories and the storm of longing rising inside her.

Outside, the wind lashed against the glass, syncing with her pounding heartbeat, threatening to explode.

Behind her, Quan said nothing. He simply tightened his arms around her waist — steady, warm. No demands. No rush. But no retreat either.

Ha Anh tilted her head slightly. His lips found her ear, whispering with hot, damp breath:  
"I'm here. You don’t need to say a thing..."

Then he kissed her. No longer tentative — but with fire. From her neck, across her shoulder, down to the trembling curve of her collarbone.  
Wherever his lips touched, her skin awoke like after a long sleep.

Ha Anh turned to face him. Her eyes glassy. She looked up at him — no longer resisting, but surrendering. A surrender both proud and desperate.

She kissed him. Her lips reached for his — hungry, trembling, like a child returning to a long-lost embrace.  
Their kiss deepened — fierce, uninterrupted, as if stopping would shatter it all.

Quan lifted her. Ha Anh wrapped her arms around his neck, burying her face into the hollow of his shoulder — where his scent lingered like an addictive drug.

He laid her on the bed — as gently as placing something sacred on the altar of desire.  
Her towel slipped away. Her naked body revealed beneath the soft, golden light. She moved to cover her chest, but Quan stopped her.

He looked at her for a long time — said nothing, just placed a hand on her left breast, over her racing heart:  
"Right here… you're still the same girl I once loved."

Then he lowered his head. His mouth wrapped around her soft breast. His tongue circled her stiffening nipple — tender yet intense.  
Ha Anh arched. A gasp escaped her lips — involuntary, raw.

He took his time. His left hand traced her spine — from the nape to her lower back, each vertebra shivering.  
His right hand slipped lower — across her belly, past her navel, and paused at the warm, wet triangle of her desire.

He didn’t enter. Just traced the outer folds with one finger — like a wind dancing over water and fire.  
She twitched slightly, but didn’t resist. Her legs parted. Her body responded like a night flower blooming under a summer rain.

Outside, a low rumble of thunder echoed — awakening something primal in her.

As his finger slid inside, she arched, moaning:  
"Ah... don't... don’t be rough..."  
But her eyes begged: *Don’t stop...*

Quan continued — gentle at first, then firmer. Ha Anh clutched the bedsheet, trembling.  
One hand still caressed her breast, the other played with her drenched petals.  
She heard her own heartbeat — erratic, wild — mingling with the steady patter of rain on glass.

Then he spread her legs wider, sliding between them. His erection was hard as stone, burning like fire.  
When its tip touched her wet entrance, Ha Anh jerked — but didn’t pull away. She only whispered:  
"Quan… go slow…"

He looked at her, said nothing, kissed her forehead — then pushed in gently.

As he entered her, a flicker of memory surfaced — her husband’s brief, silent sessions. No kisses. No foreplay. No whispers. Just duty.  
But now... Quan was inside her — with heart, with eyes, with every tender thrust.

The fullness wasn’t just physical — it was the overwhelming presence of a real man.  
She shuddered — not in pain, but because for the first time… she felt like a woman.  
For the first time in years of a cold marriage — she felt someone truly entering her.

Full. Overwhelmed. Yet... something hollow deep within finally felt complete.  
Every movement erased the nights she lay alone. Slow at first, then building — until the old bed creaked with each rhythm.

The wind still howled. Rain still fell. And they — tangled together like two souls meeting in a storm.  
Ha Anh moaned — soft at first, then louder, unashamed.  
She called his name. Clung to him. Cried.

But not from guilt — from the release of finally being heard.  
"Just like that... don’t let me go..." — she sobbed between thrusts — both in pain and in ecstasy.

Quan didn’t answer. He just held her tighter — as if melting into her, piece by piece.

And then, at the deepest point — as her body clenched around him, a broken moan on her lips —  
Quan exhaled, thrust one final time... and stopped, his body trembling.

A hot rush spilled inside her.  
Ha Anh’s eyes widened — her whole body lit up, confused, lost, yet wrapped in a strange fullness.

She could hear it — the pulsing deep within, the warmest part of her just filled.

Neither spoke. Only breath tangled. Rain whispered beyond the glass.  
And here — in this small room — two souls had touched something far beyond flesh.

...She didn’t know how long the night would last.  
But she knew — she would never be the same again.
