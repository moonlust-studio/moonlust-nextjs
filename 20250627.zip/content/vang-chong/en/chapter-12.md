# Chapter 12 – In His Arms, Yet Out of Rhythm

📖 **Teaser:** When guilt begins to taste like desire, even silence burns.

---

"There are moments when I still lie obediently in your arms… but my heart has long wandered elsewhere."

The bedroom remained unchanged—the old wedding bed, the faint scent of fabric softener lingering in the sheets, the golden bedside lamp casting a warm glow over Ha Anh's bare back. Her husband—just back from a two-month business trip—was sleeping soundly, his breathing steady and deep. Beads of sweat still clung to his stomach from the lovemaking earlier. A proper, complete act of love… by marital standards.

Yet why did her heart feel so hollow?

Ha Anh turned over, gently pulling the blanket over her chest. Sleep evaded her. Her eyes remained wide open in the dark.

Outside the window, rain tapped softly against the metal roof, the wind whispering through cracks—sounding like a quiet sob from the soul. Memories of Quan—their secret days, his lips burning down her spine, the embrace that left her breathless—played like a slow-motion reel, threading through each exhale.

With her husband, everything had become routine. From the way he held her to the way he touched her. Nothing was wrong… but nothing stirred her heart anymore. No surprises. No shiver of anticipation when a fingertip grazed her skin.

> "Tired?" her husband mumbled.  
> "No… just having trouble sleeping."

He turned to hold her from behind. A familiar embrace. An arm around her waist, a leg draped over hers. Warm body, steady breath.

But in that moment—in his arms—Ha Anh felt cold.

She closed her eyes. In the darkness, she imagined herself in the old hotel room, where Quan once whispered:  
> "You don’t have to be so strong here. Just breathing… makes me want to take you."

A single drop slid from the corner of her eye to the pillow. Was it a tear… or sweat?

Her husband’s hand suddenly found its way between her thighs. Ha Anh flinched slightly, but said nothing. He stroked her soft pubic mound, then slowly trailed his fingers along the damp folds.

She didn’t resist. Movements unfolded like a familiar script—a silent play where the actors no longer felt their roles.

He made love to her—slow, rhythmic, like a husband reunited with his wife. But Ha Anh was drifting elsewhere. Her mind detached from her body, floating into memory.

She bit her lip, suppressing a moan. Not from pleasure. But from guilt.

When it ended, when he drifted back into sleep, she remained awake—eyes wide, heart aching.

> "I’m still your wife. But my soul… is no longer here."

---

The next morning, Ha Anh sat alone on the balcony, holding a mug of black coffee. Morning light filtered through the trees, reflecting off her tousled hair. Sparrow songs mingled with the distant sound of traffic—a melody both familiar and estranged.

Her phone vibrated.  
**[Quan: You okay?]**

She stared at the message. Didn’t reply right away. Deleted it… then typed again.  
**[Fine.]**

Just one word. But inside her, a thousand shards.

Her husband stepped out, resting a hand on her shoulder:  
> "Let’s have lunch with my parents today. They miss little Minh."

She nodded, offering a soft smile. But her hand clutched the phone tightly—as if holding onto something slipping away.

She tried to blend back into the role of a loving wife. Every moan, every dirty word played like a rehearsed line.

But inside—was emptiness.

Ha Anh could only climax when he bent her over the kitchen counter in doggy position. Eyes shut tight, breath ragged with abandon.

But the man she imagined… wasn’t her husband. It was Quan.

The moans built, urgent and raw, and in a moment of losing herself, she nearly whispered, “Quan…”

The only time she reached ecstasy—was when her memory brought him back.

---

And then… she began to notice her husband had changed too.

Positions they’d never tried before… became common. He wanted her to sit on his face, devouring her sweetness with fervor. Once, he pinned her to the window, tugged her hair, slapped her ass—wild and primal.

She felt pleasure—yes. But with it, a creeping doubt.

> Has he… touched someone else while abroad?

Memories returned.

Their wedding night—he’d trembled while unbuttoning her blouse. His hands clumsy, his eyes shy, barely daring to look at her chest. He whispered:  
> “I’ll be gentle… I just don’t want to hurt you.”

Back then, she was confused, but deeply moved. Every move was slow, tender—as if he feared breaking a flower.

Now, that same man… shoved her against the window, whispered vulgar things that made her feel more startled than aroused.

She didn’t know when the tenderness disappeared. Or whether someone else had taught him those things.

She herself was torn.

He was her first. A good man. But her body… no longer belonged to him.

That hidden place was always warm, always yearning for something rougher, deeper… something Quan once gave.

---

A few days later.

A gloomy morning. Drizzle painted the streets. Cars passed like shadows.

Her husband carried his suitcase. Ha Anh bid him farewell with a long hug, a light kiss, and tired eyes dark from sleepless nights.

Last night, he’d taken her over and over, in every wild position he could.

> "Take care… Minh and I will be fine," she told him.

As the car disappeared around the corner, Ha Anh turned quickly—almost running—toward the apartment complex behind her office.

**Third floor. Room 302.**

Her hand trembled as she entered the code. The door clicked open.

No words. No waiting.

She burst in—pushing Quan against the door.

The slam echoed like the final curtain of one play… and the opening act of another—where she belonged to no one.  
> "Ha… Ha Anh… You… oh God…"
