Hà Anh khẽ đẩy cánh cửa bước vào căn hộ nhỏ. Ánh chiều muộn vương vãi trên nền gạch, nhuộm bức tường trắng bằng sắc vàng hanh hao đến mỏi mệt. Cô tháo giày, treo áo khoác lên móc. Rồi nhẹ nhàng thả mình xuống sofa, thở hắt ra một hơi dài – như thể đang buông bớt những vướng víu lặng thầm bám theo suốt cả ngày.

Đồng hồ điểm sáu giờ. Căn phòng vẫn lặng im như mọi ngày. Chồng cô – anh đang công tác ở nước ngoài, đã gần hai năm. Những cuộc gọi video thưa dần, những dòng tin nhắn chỉ còn lại vài chữ: "Anh bận quá.", "Anh đang họp.", "Lúc nào rảnh anh sẽ gọi."

Ban đầu, Hà Anh tự an ủi: vì công việc, vì tương lai, vì hai chữ gia đình. Nhưng rồi, sự trống trải cứ lặng lẽ len lỏi vào từng khoảnh khắc thường nhật – khi cô ăn một mình, khi nằm trằn trọc trong bóng tối, khi vô thức quờ tay sang bên giường rồi khựng lại giữa khoảng không lạnh.

Cô không than vãn. Không trách móc. Vẫn là người vợ được xem là mẫu mực – đi làm, về nhà, chăm con, gọi điện hỏi thăm mẹ chồng. Nhưng có những ngày, khi bắt gặp ánh nhìn của chính mình trong gương, Hà Anh giật mình. Ánh mắt ấy không còn long lanh. Nụ cười ấy không còn tự nhiên. Có điều gì đó trong cô đã lặng lẽ trôi đi – như sợi tóc rơi không tiếng động.

Buổi tối, sau bữa ăn đơn giản, Hà Anh pha cho mình một tách trà ấm. Ngồi tựa bên khung cửa sổ, cô nhìn những ánh đèn lập lòe phía xa. Thành phố vẫn đông, vẫn sáng, nhưng lòng cô lại mênh mang như một bản nhạc không lời ngân mãi trong không trung.

Chiếc điện thoại chợt sáng. Không phải chồng. Chỉ là quảng cáo. Cô đặt xuống, mắt khẽ nhắm lại. Một khoảng lặng dâng lên trong lồng ngực – mềm như sóng, nhưng đủ khiến tim rung.

Và trong giây phút ấy, một cái tên cũ lướt ngang qua trí nhớ – mơ hồ, mong manh như làn khói trà vừa tan – nhưng cũng đủ để trái tim cô khẽ rung lên một nhịp khác lạ.

Đúng lúc đó, chuông cửa vang lên. Hà Anh khựng lại. Cô không đợi ai. Đứng trước cửa là người phụ nữ hàng xóm, tay cầm hộp bánh, miệng cười tươi:  
> "Chị ơi, nhà em làm bánh hơi nhiều, biếu chị ít ăn thử. Em nghe chị sống một mình... chắc cũng buồn."

Hà Anh nhận bánh, cảm ơn. Rồi đứng lặng rất lâu sau khi khép cửa lại. Câu "sống một mình" cứ vang lên trong đầu cô, chậm rãi và day dứt.

Phải rồi. Cô sống một mình. Trong một mối quan hệ vẫn mang tên gọi là vợ chồng.

Đêm. Hà Anh nằm nghiêng, kéo chăn lên ngang ngực. Cô trở mình. Lại xoay. Rồi mở mắt nhìn trần nhà. Ánh sáng dịu nhẹ từ đèn ngủ không đủ xua đi khoảng trống đang len vào từng ngóc ngách tim cô.

Cô nhớ chồng. Hay đúng hơn – nhớ cảm giác được yêu. Được chạm vào. Được một bàn tay siết nhẹ nơi eo, một hơi thở phả bên cổ, một cái ôm thật chặt trong bóng tối.

Cảm giác đó – bao lâu rồi? Cô không đếm nữa. Vì càng đếm, khoảng cách lại càng xa.

Sống mũi cay cay. Không vì yếu đuối. Mà vì trái tim, dù mạnh mẽ đến đâu, cũng có lúc mỏi mệt khi phải tự gồng mình giữa khoảng lặng quá dài.

Một giọt nước mắt chậm rãi lăn xuống gối. Hà Anh không lau. Cô để nó trôi – như cánh cửa khẽ mở ra một góc nhỏ cảm xúc mà bấy lâu cô đã khóa lại.

Và trong khoảnh khắc mơ hồ giữa hai nhịp thở, hình ảnh một người bất chợt hiện về – ánh mắt dịu dàng, giọng nói trầm khàn, những buổi chiều mưa dưới mái hiên ký túc năm nào…

Những ngón tay đan nhau ấm áp trên sân trường, những cái chạm nhẹ mà khiến tim run rẩy. Không hẳn là hoài niệm, mà là… sự sống dậy lặng lẽ của một điều cô chưa từng quên.

Ngày mai rồi sẽ lại đến. Cô vẫn sẽ thức dậy, thoa chút son nhạt, chọn chiếc váy công sở nhẹ nhàng, mỉm cười khi bước vào thang máy.

Nhưng đêm nay, trong căn phòng chỉ còn tiếng gió lùa khe khẽ qua khung cửa, Hà Anh cho phép mình yếu lòng. Chỉ một chút thôi.

Và có lẽ, ở đâu đó trong tim, một phần ký ức xưa cũ vừa khe khẽ xoay mình thức dậy.

Rồi mai, cô lại là người vợ vững vàng như trước.
