 Chương 7: Khi Thân Thể Lên Tiếng

"Có những tiếng nói không cần lời. Chỉ cần một ánh nhìn, một cái chạm… Và thân thể sẽ tự mình trả lời tất cả."

Điện thoại vừa tắt, Hà Anh vẫn đứng im – hai tay bấu nhẹ thành cửa sổ, toàn thân như bị đóng băng giữa ngọn triều ký ức và cơn bão khát khao đang cuộn trào trong lòng.  
Gió bên ngoài quất từng đợt vào cửa kính, hòa cùng nhịp tim cô đang dồn dập như muốn nổ tung.

Phía sau, Quân không nói gì. Anh chỉ siết nhẹ vòng tay ôm lấy eo cô – vững vàng, âm ấm. Không đòi hỏi. Không vội vã. Nhưng cũng không buông.

Hà Anh khẽ nghiêng đầu. Môi anh lập tức tìm đến vành tai cô, thì thầm bằng hơi thở ướt nóng:  
“Anh ở đây. Không cần nói gì cả…”

Rồi anh hôn. Không còn là những cái chạm thăm dò – mà là chuỗi hôn cháy bỏng. Từ cổ, dọc bờ vai, tới vùng xương quai xanh đang run lên từng nhịp.  
Mỗi nơi anh lướt qua, làn da cô như bừng tỉnh sau giấc ngủ dài.

Hà Anh quay người lại. Ánh mắt cô mờ nước. Cô ngước nhìn anh – ánh nhìn không còn chống cự, mà là đầu hàng. Một sự đầu hàng vừa kiêu hãnh, vừa tuyệt vọng.

Cô chủ động hôn anh. Môi cô tìm đến môi anh – khao khát, run rẩy, như đứa trẻ lâu ngày được trở về lòng mẹ.  
Nụ hôn họ trao nhau kéo dài, cuồng nhiệt, không ngắt quãng – như thể nếu dừng lại, tất cả sẽ tan biến.

Quân bế bổng cô lên. Hà Anh quàng tay qua cổ anh, mặt vùi vào hõm vai – nơi mùi da thịt anh dày đặc như một loại thuốc gây nghiện.  
Anh đặt cô xuống giường – nhẹ như đặt một điều thiêng liêng lên bệ thờ của dục vọng.

Lớp khăn tắm tuột xuống. Cơ thể trần hiện ra trong ánh đèn vàng mờ. Hà Anh đưa tay định che ngực, nhưng Quân giữ lại.  
Anh nhìn cô thật lâu – không nói một lời, chỉ đặt tay lên ngực trái cô, nơi trái tim đang đập mạnh đến mức như muốn bật ra ngoài:  
“Ở đây… vẫn là em của ngày xưa.”

Rồi anh cúi xuống. Miệng anh ngậm lấy bầu ngực mềm. Lưỡi anh xoáy quanh đầu nhũ hồng, vừa dịu dàng, vừa dữ dội.  
Hà Anh rướn người. Một tiếng nấc bật ra khỏi cổ họng – không kìm nén nổi.

Anh không vội. Tay trái anh lướt dọc sống lưng cô – từ gáy xuống eo, từng đốt sống khẽ rùng mình. Tay phải anh luồn xuống bụng dưới. Lướt qua vùng rốn, rồi dừng lại ở tam giác mật đạo – nơi đang ẩm nóng và nhịp thở đã hoàn toàn mất kiểm soát.  
Anh không đẩy vào ngay, chỉ dùng ngón tay miết dọc mép ngoài – như đang dạo đầu bằng ngôn ngữ của gió, nước và lửa.

Cô giãy nhẹ, nhưng không chống lại. Hai chân khẽ mở rộng. Cơ thể đón lấy từng chuyển động như cánh hoa đêm bung nở dưới cơn mưa đầu hạ.

Ngoài trời, một tiếng sét vang lên, kéo dài và trầm đục – như đánh thức bản năng sâu thẳm trong cô.  
Khi một ngón tay anh trượt vào, cô cong người lên – miệng bật thành tiếng:  
“A… đừng… đừng mạnh quá…”  
Nhưng ánh mắt thì lại van nài: “Đừng dừng lại…”

Quân tiếp tục – nhịp nhàng, dịu nhẹ, rồi dần mạnh bạo. Hà Anh nắm chặt ga giường, toàn thân run lên. Một tay anh vẫn mơn trớn ngực cô, tay còn lại không ngừng vờn nơi nhụy hoa đã ướt đẫm.  
Cô nghe rõ cả tiếng tim mình đập loạn trong lồng ngực, hòa cùng tiếng mưa đều đặn ngoài cửa kính.

Rồi anh tách chân cô ra, trườn lên giữa hai đùi. Cái đó của anh đã cứng như đá, nóng như lửa.  
Khi phần đầu chạm vào khe mềm, Hà Anh giật mạnh, nhưng không lùi – chỉ thốt lên khẽ khàng:  
“Quân… từ từ thôi…”  
Anh nhìn cô, không nói gì, chỉ hôn lên trán cô – rồi đẩy nhẹ.

Trong khoảnh khắc anh thâm nhập, một thoáng ký ức về chồng cũ lướt qua tâm trí cô – những lần giao hoan chóng vánh, lặng lẽ, chỉ để “trả nghĩa làm chồng”. Không hôn, không vuốt ve, không lời thì thầm.  
Còn bây giờ… Quân ở trong cô – bằng cả trái tim, ánh mắt và từng nhịp đẩy dịu dàng nhưng sâu sắc đến tận cùng.

Cảm giác căng đầy – không chỉ bởi chiều dài, bề ngang, mà là sự hiện diện mạnh mẽ, triệt để của một người đàn ông thực sự.  
Cô rùng mình – không phải vì đau, mà vì lần đầu tiên, cô thật sự được làm đàn bà.

...

Và rồi, giữa khoảnh khắc sâu nhất – khi cơ thể cô co siết mãnh liệt, miệng cô bật ra tiếng rên nghẹn ngào – Quân thở hắt, rướn mạnh lần cuối cùng… rồi dừng lại, cơ thể anh run nhẹ.  
Một dòng ấm nóng trào ra bên trong, cảm giác vừa giật giật vừa tuôn trào vào sâu bên trong...ư....Hà Anh ưỡng cao ngực đón nhận

Hà Anh mở to mắt, cả người như bừng lên – vừa bối rối, vừa say mê, vừa lặng người vì cảm giác trọn vẹn đến lạ.  
Cô nghe rõ cả tiếng mạch đập trong cơ thể mình – nơi sâu nhất, ấm nhất, vừa được ai đó lấp đầy.

Không ai nói gì. Chỉ có hơi thở đan vào nhau, tiếng mưa ngoài kia vẫn đều đặn.  
Và ở đây – trong căn phòng nhỏ – hai con người vừa chạm vào một điều gì đó… lớn hơn cả thân xác.

…

*Cô không biết đêm nay còn kéo dài bao lâu, nhưng cô biết – mình sẽ không còn như trước nữa.*  
