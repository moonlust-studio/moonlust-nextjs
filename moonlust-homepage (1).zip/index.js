import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Hero Section */}
      <div className="relative h-[70vh] flex flex-col justify-center items-center text-center px-4 bg-cover bg-center" style={{ backgroundImage: "url('/hero-banner.jpg')" }}>
        <div className="bg-black/60 p-6 rounded-2xl shadow-xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Moonlust</h1>
          <p className="text-lg md:text-xl mb-6">Truyện người lớn cảm xúc, tinh tế, đắm say.</p>
          <Link href="/truyen/co-thu-ky/chuong-1">
            <span className="inline-block bg-white text-black px-6 py-2 rounded-full font-semibold hover:bg-pink-500 hover:text-white transition">Khám phá ngay</span>
          </Link>
        </div>
      </div>

      {/* Featured Story */}
      <div className="py-16 px-6 md:px-20">
        <h2 className="text-3xl font-bold mb-8 text-center">Truyện Nổi Bật</h2>
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <img src="/thu-ky-thumb.jpg" alt="Cô Thư Ký" className="rounded-2xl shadow-lg w-full object-cover" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-2">Cô Thư Ký</h3>
            <p className="mb-4 text-gray-300">Một câu chuyện về cám dỗ, kìm nén và đam mê giữa hai người trưởng thành – vừa say đắm, vừa giằng xé.</p>
            <Link href="/truyen/co-thu-ky/chuong-1">
              <span className="inline-block bg-pink-600 text-white px-4 py-2 rounded-full font-medium hover:bg-pink-400 transition">Đọc ngay →</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Danh Mục Truyện */}
      <div className="bg-gray-950 py-12 px-6 md:px-20">
        <h2 className="text-2xl font-bold mb-6 text-center">Danh Mục Truyện</h2>
        <div className="flex flex-wrap justify-center gap-4">
          {['Hoàn thành', 'Đang viết', 'Drop', 'Trinh thám', 'Kiếm hiệp', 'Ngôn tình', 'Cung đấu'].map((category) => (
            <span key={category} className="bg-gray-800 hover:bg-pink-600 text-white px-4 py-2 rounded-full cursor-pointer transition">
              {category}
            </span>
          ))}
        </div>
      </div>

      {/* Tìm kiếm */}
      <div className="bg-black py-12 px-6 md:px-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Tìm kiếm truyện</h2>
        <input
          type="text"
          placeholder="Nhập tên truyện, tác giả..."
          className="w-full md:w-1/2 px-4 py-3 rounded-xl text-black outline-none"
        />
      </div>

      {/* Truyện nhiều người đọc nhất */}
      <div className="bg-gray-950 py-12 px-6 md:px-20">
        <h2 className="text-2xl font-bold mb-6 text-center">Truyện Được Đọc Nhiều</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((item) => (
            <div key={item} className="bg-gray-800 p-4 rounded-xl shadow-md">
              <img src="/thumb-placeholder.jpg" alt="Truyện" className="rounded-md mb-3 w-full h-48 object-cover" />
              <h4 className="text-lg font-semibold mb-1">Tên Truyện {item}</h4>
              <p className="text-gray-400 text-sm">Tác giả: Tác giả {item}</p>
              <p className="text-gray-500 text-xs">Lượt đọc: {(item * 1234).toLocaleString()}+ lượt</p>
            </div>
          ))}
        </div>
      </div>

      {/* Danh sách tất cả truyện */}
      <div className="bg-black py-16 px-6 md:px-20">
        <h2 className="text-2xl font-bold mb-6 text-center">Tất Cả Truyện</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="bg-gray-800 rounded-xl shadow-md overflow-hidden">
              <img src="/thumb-placeholder.jpg" className="w-full h-40 object-cover" alt={`Truyện ${i + 1}`} />
              <div className="p-4">
                <h4 className="text-lg font-semibold">Truyện Demo {i + 1}</h4>
                <p className="text-sm text-gray-400 mb-2">Thể loại: Tình cảm</p>
                <Link href="#">
                  <span className="text-pink-500 text-sm hover:underline">Xem chi tiết →</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* About Moonlust */}
      <div className="bg-gray-900 py-12 px-6 md:px-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Về Moonlust</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Moonlust là không gian ẩn danh để bạn tận hưởng những câu chuyện người lớn với chiều sâu cảm xúc. Không thô tục, không rẻ tiền — chỉ có gợi cảm, tinh tế và nghệ thuật.
        </p>
      </div>
    </div>
  );
}