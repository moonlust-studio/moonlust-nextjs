export const defaultSEO = {
  title: "Moonlust | Truyện người lớn tinh tế & nội tâm",
  description: "Moonlust là website đọc truyện người lớn văn minh, cảm xúc sâu sắc, nội dung gợi cảm nhưng không thô tục.",
  keywords: "truyện người lớn, truyện 18+, truyện sex tinh tế, truyện nội tâm, truyện cảm xúc, moonlust",
  openGraph: {
    images: [
      {
        url: "/og-cover.jpg",
        width: 1200,
        height: 630,
        alt: "Moonlust Preview"
      }
    ]
  }
};