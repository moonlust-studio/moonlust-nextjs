import { useRouter } from 'next/router'

const translations = {
  vi: {
    title: "Trâm Anh & Hùng – Vùng Cấm Nơi Công Sở",
    chapters: [
      "Chương 1 – Ánh Nhìn Đầu Tiên",
      "Chương 2 – Gác Cửa Đêm Thôi Miên",
      "Chương 3 – Hòa Tan"
    ],
    back: "← Quay về trang chủ"
  },
  en: {
    title: "Tram Anh & Hung – Forbidden Office Affair",
    chapters: [
      "Chapter 1 – First Glance",
      "Chapter 2 – The Hypnotic Night Gate",
      "Chapter 3 – Melt Into One"
    ],
    back: "← Back to homepage"
  },
  ja: {
    title: "チャムアンとフン – オフィスの禁断の関係",
    chapters: [
      "第1章 – 最初の視線",
      "第2章 – 催眠の夜の扉",
      "第3章 – 溶け合う"
    ],
    back: "← ホームに戻る"
  }
};

export default function useLanguage() {
  const { locale } = useRouter();
  const lang = ['en', 'ja'].includes(locale) ? locale : 'vi';
  return { lang, t: translations[lang] };
}