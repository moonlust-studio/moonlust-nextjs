const storyTranslations = {
  vi: {
    title: "Trâm Anh & Hùng – Vùng Cấm Nơi Công Sở",
    chapters: [
      "Chương 1 – Ánh Nhìn Đầu Tiên",
      "Chương 2 – Gác Cửa Đêm Thôi Miên",
      "Chương 3 – Hòa Tan"
    ],
    back: "← Quay về trang chủ",
    content: [
      "Trâm Anh bước vào phòng họp, áo sơ mi trắng ôm nhẹ...",
      "Ánh trăng xuyên qua rèm cửa, lấp lánh trên gương mặt Trâm Anh khi cô bước vào căn penthouse đêm...",
      "Ánh sáng mờ, tiếng thở nồng cháy vang lên như nhịp du dương của đêm khó quên..."
    ]
  },
  en: {
    title: "Tram Anh & Hung – Forbidden Office Affair",
    chapters: [
      "Chapter 1 – First Glance",
      "Chapter 2 – The Hypnotic Night Gate",
      "Chapter 3 – Melt Into One"
    ],
    back: "← Back to homepage",
    content: [
      "Tram Anh walked into the meeting room, her white blouse hugging her frame...",
      "Moonlight filtered through the curtains, casting a soft glow on Tram Anh’s face...",
      "Dim lighting. Heated breaths. Each breath a rhythm of desire..."
    ]
  },
  ja: {
    title: "チャムアンとフン – オフィスの禁断の関係",
    chapters: [
      "第1章 – 最初の視線",
      "第2章 – 催眠の夜の扉",
      "第3章 – 溶け合う"
    ],
    back: "← ホームに戻る",
    content: [
      "チャムアンは会議室に入った。白いブラウスが彼女の体を優しく包み...",
      "月明かりがカーテン越しに差し込み、チャムアンの顔を柔らかく照らす...",
      "淡い照明。熱を帯びた吐息。ひとつひとつの呼吸が、欲望の旋律となる..."
    ]
  }
};

export default storyTranslations;