import SeoHead from '@/components/SeoHead'
import Image from 'next/image'
import Link from 'next/link'
import useLanguage from '@/utils/useLanguage'
import storyTranslations from '@/translations/story/tram-anh-va-hung'

export default function TramAnhVaHung() {
  const { lang, t } = useLanguage()
  const content = storyTranslations[lang]?.content || []

  return (
    <>
      <SeoHead title={t.title} description="Một mối tình công sở gợi cảm, giằng xé, sâu sắc." />
      <main className="px-4 py-8 max-w-3xl mx-auto text-gray-800 dark:text-white">
        <h1 className="text-3xl font-bold mb-4">{t.title}</h1>
        <Image
          src="/assets/images/truyen/tram-anh-va-hung/logo.jpg"
          width={800}
          height={400}
          alt="Truyện Trâm Anh & Hùng"
          className="rounded-xl shadow mb-8"
        />
        {content.map((chapter, idx) => (
          <article key={idx} className="mb-12">
            <h2 className="text-2xl font-semibold mb-2">{t.chapters[idx]}</h2>
            <Image
              src={`/assets/images/truyen/tram-anh-va-hung/cover-chuong-${idx + 1}.jpg`}
              width={800}
              height={400}
              alt={`Ảnh minh họa chương ${idx + 1}`}
              className="rounded-lg shadow mb-4"
            />
            <p className="whitespace-pre-line">{chapter}</p>
          </article>
        ))}
        <Link href="/" className="text-blue-600 hover:underline">
          {t.back}
        </Link>
      </main>
    </>
  )
}