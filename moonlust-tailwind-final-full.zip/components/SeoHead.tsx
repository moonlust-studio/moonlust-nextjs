import Head from 'next/head'
import { defaultSEO } from '@/utils/seoConfig'

export default function SeoHead({ title = defaultSEO.title, description = defaultSEO.description }) {
  return (
    <Head>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={defaultSEO.keywords} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={defaultSEO.openGraph.images[0].url} />
    </Head>
  )
}