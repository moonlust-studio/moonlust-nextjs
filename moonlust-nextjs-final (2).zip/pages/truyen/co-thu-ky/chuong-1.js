export default function Ch1() {
  return (
    <div style={{ padding: 50 }}>
      <h1>📝 Chương 1</h1>
      <p>Khởi đầu của cuộc giằng xé giữa lý trí và ham muốn...</p>
    </div>
  );
}