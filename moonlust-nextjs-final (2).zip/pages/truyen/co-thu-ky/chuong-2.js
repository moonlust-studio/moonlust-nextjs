export default function Ch2() {
  return (
    <div style={{ padding: 50 }}>
      <h1>📝 Chương 2</h1>
      <p>Chuyến công tác mở ra một đêm định mệnh...</p>
    </div>
  );
}