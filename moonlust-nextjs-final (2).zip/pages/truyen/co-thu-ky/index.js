export default function Truyen() {
  return (
    <div style={{ padding: 50 }}>
      <h1>📖 Cô Thư Ký</h1>
      <p>Một câu chuyện về giằng xé cảm xúc và đam mê bị kìm nén...</p>
    </div>
  );
}