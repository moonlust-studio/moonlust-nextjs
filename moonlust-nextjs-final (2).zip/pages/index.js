import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-950 text-pink-100 font-serif">
      <header className="text-center py-8 border-b border-pink-900">
        <div className="flex flex-col items-center">
          <div className="flex items-center space-x-3">
            <div className="text-4xl">🌙</div>
            <div className="text-4xl font-bold text-pink-300 tracking-wide" style={{ fontFamily: 'Playfair Display' }}>
              Moonlust
            </div>
          </div>
          <p className="mt-2 text-pink-400 italic">Truyện người lớn tinh tế – đầy nội tâm – đậm cảm xúc</p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-bold text-pink-300 text-center mb-6">📖 Truyện nổi bật</h2>
        <div className="grid gap-6">
          <Link href="/truyen/co-thu-ky">
            <a className="block p-4 border border-pink-700 rounded-lg hover:bg-pink-900 transition">
              <h3 className="text-xl font-semibold">📖 Cô Thư Ký</h3>
              <p className="text-sm text-pink-400">Một câu chuyện về giằng xé cảm xúc và đam mê bị kìm nén...</p>
            </a>
          </Link>
          <Link href="/truyen/co-thu-ky/chuong-1">
            <a className="block p-4 border border-pink-700 rounded-lg hover:bg-pink-900 transition">
              <h3 className="text-lg font-medium">📝 Chương 1</h3>
              <p className="text-sm text-pink-400">Khởi đầu của cuộc giằng xé giữa lý trí và ham muốn...</p>
            </a>
          </Link>
          <Link href="/truyen/co-thu-ky/chuong-2">
            <a className="block p-4 border border-pink-700 rounded-lg hover:bg-pink-900 transition">
              <h3 className="text-lg font-medium">📝 Chương 2</h3>
              <p className="text-sm text-pink-400">Chuyến công tác mở ra một đêm định mệnh...</p>
            </a>
          </Link>
        </div>
      </main>

      <footer className="text-center text-sm text-pink-700 py-8 border-t border-pink-900">
        <p>&copy; 2025 Moonlust. All rights reserved.</p>
        <div className="mt-2">
          <a href="/chinh-sach" className="underline hover:text-pink-500">Chính sách bảo mật</a> ·
          <a href="/dieu-khoan" className="underline hover:text-pink-500">Điều khoản sử dụng</a> ·
          <a href="/lien-he" className="underline hover:text-pink-500">Liên hệ & quảng cáo</a>
        </div>
      </footer>
    </div>
  );
}