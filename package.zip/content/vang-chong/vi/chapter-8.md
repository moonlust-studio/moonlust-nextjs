Chương 8: Đêm Thức Trắng

**"Khi thân thể đã mở lời, linh hồn cũng không thể im lặng."**

Hà Anh nằm nghiêng, mái tóc rối phủ một phần lưng trần. Ánh đèn ngủ vàng dịu hắt lên làn da ửng hồng còn vương hơi thở ái ân.
Quân nằm sau lưng cô, tay vẫn ôm trọn lấy eo. Hơi thở anh đều và sâu – nhưng ánh mắt vẫn mở, như khắc ghi từng nhịp run rẩy vừa rồi.
Cô chưa ngủ. Cơ thể vẫn còn tê dại, nhưng trong lòng… như có dòng suối lũ cuộn trào – không dừng lại được.

Bàn tay cô chạm nhẹ vào tay anh đưa tay lên xoa ngực săn chắc đầy nam tính của Quân,không dừng lại ở đó từ từ cô xoa xuống bụng và đích tới của cô là nơi cậu nhỏ to đùng và nóng ấm đã bật dậy ngay khi bàn tay cô chạm tới, rồi quay đầu lại, môi khẽ nhếch thành một nụ cười rất nhỏ:
“Anh còn muốn nữa không?”

Quân nhìn cô. Không đáp. Nhưng ánh mắt anh – sáng lên như có lửa.
Anh lật người, đặt cô nằm ngửa, rồi cúi xuống hôn lên bầu ngực vừa mới lắng lại.
“Em hỏi thừa rồi.”

Lần này, chính Hà Anh là người chủ động. Cô vòng chân lên hông anh, kéo anh sát lại. Tay cô lần xuống, cầm lấy cái đó của anh – ấm, cứng, căng tràn – rồi đặt nó lên môi mình.
Cô hôn lên đỉnh đầu như vuốt ve một điều thiêng liêng. Lưỡi cô lướt nhẹ dọc thân, ánh mắt vẫn không rời ánh mắt anh – khiêu khích và đầy mê hoặc.

Quân khẽ rên, toàn thân căng như dây cung. Anh siết chặt ga giường khi đầu lưỡi cô chơi đùa quanh phần gân nổi, rồi ngậm lấy – sâu dần, sâu dần – đến tận gốc.
“Em… học cái này từ đâu vậy?” – anh thì thầm, vừa thở hắt, vừa rên khẽ.
“Không phải từ chồng em.” – cô nhếch môi, giọng nửa thật nửa trêu, rồi lại tiếp tục nuốt trọn lấy anh – chậm rãi hơn, đều đặn như một bản nhạc du dương giữa đêm.

Âm thanh ướt át vang lên trong căn phòng yên tĩnh. Tiếng rên rỉ hòa cùng tiếng mút mềm và hơi thở nặng nhọc, nóng ran.
Khi Quân sắp không chịu nổi nữa, cô dừng lại – trèo lên người anh, giữ hai tay anh trên đầu, và tự mình ngồi xuống.

Cảm giác được anh tràn vào từ dưới lên khiến cô bật ra một tiếng rên vừa run rẩy, vừa mãn nguyện:
“Ư… trời ơi… sâu quá… em thích quá…to quá…dài quá…Quân ơi”

Cô bắt đầu nhấp nhịp – chậm rãi, đều đặn, rồi nhanh dần. Bầu ngực cô nảy lên theo từng cú nhấn. Mồ hôi lấm tấm trên cổ, trên ngực, trên bụng – ánh đèn hắt vào khiến cơ thể cô như phát sáng giữa căn phòng tối mờ.
“Chồng em chưa từng thấy em như thế này…” – cô rít khẽ, rồi cúi xuống, cắn nhẹ vào tai anh – “Anh có biết… em đã khao khát cảm giác này bao lâu rồi không?”

Quân lật cô lại, nhấc chân cô lên vai – rồi dập xuống, mạnh mẽ, mãnh liệt.
Tiếng va chạm ướt át vang vọng, hòa cùng tiếng thở gấp, tiếng nức nở của Hà Anh:
“Sâu quá… a… a… nữa đi anh… đừng dừng lại…”

Tư thế thay đổi liên tục: cô quỳ bò, anh từ phía sau; rồi cô nằm nghiêng, co một chân lên để anh thâm nhập sâu hơn, rồi anh ngồi trên ghế, cô ngồi lên anh, hai tay vòng quanh cổ – lưng cô cong lại, ngực dán sát ngực anh, từng nhịp chuyển động như thôi miên.

“Anh… chỗ đó… mạnh lên… a… đừng tha cho em đêm nay…”

Mỗi lần cô lên đỉnh là mỗi lần cô bật khóc – không phải vì đau, mà vì khoái cảm như cơn sóng cuốn sạch mọi lớp vỏ bọc.
Cô không còn là người vợ lạnh lẽo, không còn là người mẹ mẫu mực – chỉ là một người đàn bà thèm được yêu, được thấu hiểu, được tan ra trong vòng tay một người thật sự lắng nghe thân thể cô.

“Quân… em… sắp nữa rồi… đừng dừng… đừng dừng…”
“Rên lớn lên đi, Hà Anh… cho anh nghe hết tiếng thật của em đêm nay…”

Đêm ấy, họ làm tình đến lần thứ ba, thứ tư… Không đếm nữa. Cô thiếp đi rồi lại bị anh đánh thức bằng một nụ hôn giữa hai đùi.
Cô mơ màng cười trong nước mắt. Cô rên rỉ bằng tên anh. Và khi trời hửng sáng, khi mưa ngoài kia đã ngừng, cả hai vẫn chưa rời khỏi nhau.

Trước khi chìm vào lần cuối, Hà Anh rướn lên, ghé môi sát tai anh, thì thầm bằng giọng run rẩy nhưng tha thiết:
“Lần này… em muốn nó… trong miệng em. Cho em được nếm hương vị của anh… được không?”

Câu nói như đốt cháy toàn bộ lý trí còn sót lại trong Quân.
Anh thở dốc, nâng người dậy, để cô nằm ngửa, đầu ngẩng lên chờ đợi.

Khi anh đứng bên mép giường, Hà Anh chủ động mở môi, đôi mắt long lanh, lưỡi nhẹ liếm quanh đầu khấc đang căng cứng – rồi ngậm vào.
Quân siết chặt tóc cô, rên thành tiếng:
“Trời ơi… Hà Anh… anh mơ điều này từ hồi sinh viên…”

Cô mút sâu, đều nhịp – nước miếng và hơi nóng hòa quyện thành âm thanh ướt át, vang vọng khắp căn phòng.
Cô rướn người, dùng cả tay lẫn môi, khiến anh gồng cứng, từng đường gân nổi rõ.
Cô không ngừng rên nhẹ trong cổ họng – như bản nhạc dồn dập kích thích cả thân lẫn tâm.
“Nữa đi em… anh không chịu nổi nữa… a…”

Và rồi – trong tiếng rên nặng trĩu và tiếng gọi tên cô nghẹn ngào – Quân bật người, giữ đầu cô sát lại… rồi bắn.
Từng đợt, từng đợt đặc nóng tràn vào miệng, lên lưỡi, xuống cổ họng.

Hà Anh không tránh. Cô nuốt lấy hết, từ từ, rồi hé môi thở hắt ra một tiếng rên đầy mãn nguyện:
“Mặn… nhưng là mùi vị của người em muốn giữ mãi…”

Quân ôm cô vào lòng, siết chặt như thể vừa giao hết tâm can.
Cả hai chìm vào nhau – không còn thời gian, không còn mưa gió ngoài kia – chỉ còn là những nhịp tim đang hòa làm một.

**Đêm nay – thân thể cô đã thật sự sống lại. Và tiếng nói từ sâu thẳm ấy… cuối cùng cũng được nghe thấy.**