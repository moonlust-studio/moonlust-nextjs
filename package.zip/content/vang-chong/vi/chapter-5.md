Chương 5: Những Ly Rượu Của Nỗi Nhớ 

"Có những cuộc gặp không cần lên giường cũng đủ khiến người ta run rẩy suốt đêm."

Quán ốc cũ nằm nép mình dưới tán cây bàng già, ánh đèn vàng hắt lên lớp khói mỏng nghi ngút bay ra từ những mẹt ốc luộc, nghêu xào, sò nướng. Hơi men lẫn vào mùi sả, gừng, mùi biển — tất cả như một cánh cổng nhỏ, mở ra miền ký ức ngủ yên.

Quân đến trước. Áo sơ mi xắn tay, tóc rối nhẹ như năm nào. Anh đang cúi nhìn ly rượu nếp thì bóng dáng ai đó xuất hiện.

Hà Anh đến sau. Váy lụa ngà ôm nhẹ lấy cơ thể — không quá phô bày, nhưng đủ để tôn lên những đường cong mượt mà của người đàn bà từng trải. Dáng người cô nở nang theo cách của một người mẹ một con. Vòng eo không còn phẳng như thời thiếu nữ, nhưng thay vào đó là sự đẫy đà căng tràn đàn bà — khiến mọi chuyển động đều ngân vang như một giai điệu quyến rũ.

Làn tóc xõa nhẹ, gợn sóng. Bờ vai trần thấp thoáng sau lớp lụa mỏng. Đôi mắt — vẫn là đôi mắt ấy — sâu, buồn, và đẹp như hồ nước cuối thu.

Quân ngẩng lên. Anh đứng hình một giây. Không vì cô lộng lẫy, mà bởi vẻ đàn bà mặn mà ấy — thứ vẻ đẹp chỉ thời gian mới gọt giũa, và chỉ ai đủ tinh tế mới cảm được.

“Lâu rồi mới ăn lại món này.” – cô nói, tay gắp con ốc nóng hổi.

“Nhưng vị thì vẫn như cũ. Chỉ có người ngồi cạnh không còn là cô sinh viên năm ba ngày ấy.” – Quân mỉm cười, rót chút rượu nếp vào ly cô.

Cô cầm ly, ngần ngại. Rồi cụng nhẹ. “Chỉ một ly thôi đấy.”

Nhưng cái “một ly” nhanh chóng thành hai, rồi ba. Không phải vì muốn say, mà vì cần một cái cớ để khỏi nói thật lòng.

...

[Tin nhắn từ Quân:] "Anh vẫn nhớ... đêm mưa năm ấy, em ngồi co chân trong chăn, tóc ướt dính má. Ánh mắt em lúc đó… đẹp nhất anh từng thấy."

Cô nhìn màn hình. Do dự. Rồi mở khung soạn:

[Tin nhắn gửi:] "Hôm nay… em không biết nên vui hay buồn. Nhưng có một điều em chắc: Em chưa bao giờ quên."