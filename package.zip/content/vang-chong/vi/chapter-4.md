Chương 4: Ngưỡng Cửa Tội Lỗi

“Đôi khi, những giới hạn không bị phá vỡ bởi ham muốn, mà bởi khao khát được lấp đầy một khoảng trống không thể gọi tên.”

Chiều thứ Bảy, bầu trời lặng lẽ chuyển sắc. Những tia nắng cuối ngày rơi nhẹ lên khung cửa kính, phản chiếu xuống mặt sàn bóng loáng, kéo dài thành vệt vàng như một nỗi nhớ bị níu lại giữa hoàng hôn.

Hà Anh vừa đưa con sang nhà ông bà nội – khoảng thời gian rảnh rỗi quý giá mỗi cuối tuần. Nhưng lạ thay, chính khi rảnh rỗi nhất, cảm giác cô đơn lại ùa đến rõ rệt nhất.

Cô đọc tiểu thuyết, đọc truyện – nhất là những truyện trên Moonlust. Ở đó, cô thấy mình như được soi chiếu qua từng nhân vật đàn bà vẻ ngoài đoan trang nhưng bên trong chất chứa những khao khát âm ỉ. Có lúc, cô tự hỏi: “Liệu một ngày nào đó… mình cũng sẽ giống như họ?”

Nghĩ đến đó, người cô bỗng nóng ran. Một phần sợ. Nhưng một phần lại rạo rực đến lạ. Sâu trong cô, có một khát khao thầm kín – sâu, dai dẳng, và chưa từng được chạm đến đúng cách.

Sau buổi café ấy, Hà Anh và Quân nhắn tin cho nhau nhiều hơn. Cô thấy vui. Nhưng cũng thấy có lỗi. Cô nhắc mình: “Mình đã có chồng.”

Dù vậy, từng tin nhắn từ anh như gõ nhẹ vào ký ức cô tưởng đã ngủ yên. Anh không nói nhiều về tình dục, nhưng ánh mắt ngày hôm đó… giọng nói trầm, khẽ… những chi tiết nhỏ ấy khiến cô cảm thấy được lắng nghe, được thấu hiểu, được nhìn thấy.

Và cô không thể phủ nhận cảm giác từng chút một… đang bị kéo về phía anh.

Tối hôm ấy, Hà Anh nằm nghiêng bên cửa sổ. Ánh đèn vàng dịu nhẹ hắt lên gò má, tạo thành vệt sáng mỏng manh nơi khóe mắt. Từ ngoài khung kính, tiếng quạ kêu râm ran hòa lẫn tiếng xe thưa thớt ngoài phố, như nhấn nhá thêm sự cô quạnh trong lòng.

Cô khẽ rùng mình – không hẳn vì lạnh, mà vì những dội ngược của ký ức đang ùa về. Trong làn gió mỏng thoảng qua khe cửa, mùi mưa ẩm và khói bếp len lỏi, kéo cô trở lại một buổi chiều mưa năm nào – nơi căn phòng trọ nhỏ xíu của thời sinh viên.

Chiếc quạt bàn xoay lạch cạch, đèn tuýp nhấp nháy theo nhịp điện yếu khiến không gian càng thêm mộng mị. Tường bong tróc, sàn gỗ ọp ẹp… Nhưng giữa cái nghèo ấy, có một điều rực rỡ: tình yêu đầu đời.

Họ từng ngồi học bên nhau, tay chạm tay – rồi trao nhau nụ hôn đầu vụng dại. Mỗi lần bàn tay Quân chạm vào vai, lưng, hay luồn khẽ qua mép áo, từng tế bào trong cô như vỡ tung.

Và có một chiều mưa mờ nhòe, cả hai nằm sát bên nhau trên chiếc đệm mỏng trải dưới sàn. Quân hôn cô thật sâu, thật lâu. Đôi môi anh trượt dần từ môi cô xuống cổ, ngực, rồi thấp hơn nữa…

Bất chợt, tiếng bước chân ngoài hành lang vọng lại. Hà Anh nín thở. Nhưng chỉ là người hàng xóm bước ngang. Họ lại lao vào nhau như thể phút giây đó là lần cuối được gần nhau.

Có những lần cô không cho phép tiến xa hơn, Quân đã cúi xuống… dùng miệng hôn vào nơi nhạy cảm nhất đời con gái. Cô hoảng hốt giữ lấy đầu anh – vừa ngượng, vừa bất ngờ, vừa lo ai đó nghe thấy tiếng rên khe khẽ của mình.

Nhưng rồi, trong phút chốc buông lơi, hơi thở ấm nóng ấy như cơn mưa đầu mùa đổ xuống mảnh đất khô cằn – khiến lòng cô thổn thức, vừa thẹn thùng, vừa dâng trào những cảm xúc lạ lẫm.

Cô run. Cô nghẹn. Cô khép chân lại – nhưng lại chẳng thể kháng cự hoàn toàn.

"Dừng lại đi..." – cô thốt khẽ, nhưng giọng không đủ cứng rắn. Quân ngẩng lên, nhìn cô bằng ánh mắt dịu dàng nhức nhối. Rồi anh ôm cô vào lòng thật chặt.

Tuổi mười chín đôi mươi, Quân chất chứa những ham muốn mãnh liệt – vừa ngây ngô, vừa bồng bột. Mỗi khi có chút riêng tư, anh lại cuốn lấy cô như sợ để lạc mất. Anh khao khát cô như bản năng tuổi trẻ.

Còn cô – dù sợ hãi điều chưa biết, vẫn chẳng thể chối từ anh. Vì cô yêu. Một tình yêu mãnh liệt hơn bất cứ điều gì cô từng biết.

Dù không cho phép đi quá giới hạn, nhưng trong những lần gần gũi, cô cũng chiều anh hết mức – bằng nụ hôn, cái ôm kéo dài, bằng những lần tay chạm tay, ngực chạm ngực khiến cả hai rạo rực đến tận cùng.

Và chính vì chưa từng vượt ranh giới… nên ký ức ấy mãi tinh khôi, sống động và đầy dư âm.

Có một bí mật mà suốt bao năm, cô chưa từng nghĩ đến:

Người đầu tiên chạm vào nơi nhạy cảm nhất của cô… không phải là chồng.

Và bàn tay đầu tiên cô từng rụt rè nắm lấy… cũng không phải người đàn ông cưới cô sau này.

Nhưng tất cả những điều đó – đều dừng lại ở ngưỡng ranh giới. Đủ trong sáng để gọi là tình đầu. Đủ run rẩy để cả đời không thể nào quên.
