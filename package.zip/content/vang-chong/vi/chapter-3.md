Chương 3

Đêm ấy, Hà Anh ngủ quên lúc nào không hay — đầu óc quay cuồng với những cảm xúc lẫn lộn. Trái tim rối bời. Cơ thể trống trải. Và ẩm ướt đến lạ.

Ngoài trời, gió đêm khe khẽ lùa qua tán cây, mang theo âm thanh rì rào như tiếng thì thầm từ một miền ký ức xa xăm. Ánh đèn đường hắt bóng lên trần nhà, nhạt nhòa như chính tâm trí cô.

Trong cơn mơ chập chờn, cô thấy mình đang ân ái với chồng — cuồng nhiệt, mãnh liệt. Nhưng ánh mắt người đàn ông trong mơ lại nhòe đi… không phải chồng, mà là Quân. Đôi mắt trầm sâu, tha thiết, như thiêu đốt.

Hà Anh cố xua đi, nhưng cơ thể lại cuốn theo từng nhịp thở khao khát ấy.

Cô choàng tỉnh. Tim đập loạn. Mồ hôi lấm tấm trên trán — và cả giữa hai đùi, ẩm ấm. Dư âm giấc mơ vẫn chưa tan. Cô vừa làm tình. Nhưng là với ai?

Bình minh bắt đầu len lỏi. Ánh sáng rọi qua khe rèm, rắc lên tấm ga giường một ánh hồng dịu nhẹ. Mùi vải thơm và hương tóc phai từ tối qua quyện lại — dìu dịu, gần gũi như hơi ấm cuối cùng của giấc mơ chưa kịp tàn.

Tin nhắn của Quân lại hiện về trong tâm trí: “Nếu em rảnh chiều nay, anh muốn gặp. Chỉ một lần.”

Cô không trả lời ngay. Một phần muốn xóa đi, chặn luôn cả ký ức cũ. Nhưng phần khác… lại muốn gặp. Không để nối lại, mà để hỏi. Để nhìn rõ trong mắt anh — liệu có điều gì còn chưa nói?

Ánh nắng xuyên qua tán cây ngoài cửa sổ, in bóng lấp loáng lên rèm trắng đang đung đưa. Mùi hoa nhài từ lọ tinh dầu tỏa nhẹ, mỏng như một ký ức. Căn phòng im lặng đến nỗi, cô nghe được cả tiếng thở khẽ của chính mình.

Cô cầm điện thoại lên rồi lại đặt xuống. Trong đầu, những câu hỏi xoáy vào nhau: “Mình đã có chồng… Gặp lại anh ấy, có vượt giới hạn? Hay chỉ là cuộc trò chuyện?”

Một thoáng ngập ngừng. Nhưng rồi ánh mắt Quân — đôi mắt từng làm tim cô loạn nhịp — lại hiện lên rõ mồn một. Và thế là… cô không xóa tin nhắn.

Cô ngồi lặng một lúc rất lâu. Ký ức ùa về. Thời sinh viên — tình yêu cháy bỏng tưởng không gì chia lìa. Nhưng rồi khoảng cách, gia đình, lựa chọn… cuốn họ rời xa.

Đôi mắt Hà Anh rưng rưng. Không khóc nức nở. Chỉ lặng lẽ — từng giọt rơi. Là tiếc nuối. Là sợ hãi. Là nỗi bất lực khi biết nếu gặp lại, cô khó lòng vượt qua cảm xúc ấy.

Nhưng rồi cô thì thầm, như tự dỗ mình: “Chỉ là gặp một người bạn cũ thôi mà…”

Và thế là… cô nhắn lại:

“Sao anh còn giữ số em?”

Tin nhắn được gửi đi. Một lúc sau, màn hình sáng lên.

“Anh chưa từng xóa.”

Chỉ bốn chữ. Nhưng như chạm sâu vào một nơi trong tim cô tưởng đã ngủ yên.

Chiều hôm đó, họ hẹn ở một quán cà phê ven sông — nơi từng là điểm hẹn cũ thuở sinh viên.

Quán không lớn, nhưng phảng phất mùi cà phê rang xay hòa với hương gỗ cũ. Bàn ghế mộc mạc, sơn bong theo năm tháng. Chậu hoa giấy bên hiên lay động trong gió chiều.

Hà Anh đến trước. Chọn bàn ngoài hiên. Ánh nắng chiều nhuộm vàng lên tóc cô, lên vành ly nước lọc đang xoay nhẹ trong tay.

Rồi Quân đến.

Vẫn dáng người cao, ánh mắt đượm buồn, áo sơ mi trắng hơi nhăn. Anh đứng khựng lại một nhịp khi thấy cô — như sợ khoảnh khắc này là mộng.

Khi ánh mắt họ chạm nhau, không ai nói gì. Chỉ có tiếng tim đập và khoảng lặng bao trùm.

“Lâu rồi nhỉ…” — anh mở lời, giọng trầm lẫn trong gió.

“Ừ… lâu thật.” — cô đáp, cố giữ giọng bình thản.

Gió thổi nhẹ. Mùi cà phê và hương gỗ làm sống lại ký ức.

“Anh đã từng nghĩ… nếu gặp lại em, anh sẽ nói thật nhiều. Nhưng giờ… lại chẳng biết nói gì.”

“Chỉ cần nhìn thấy anh như thế này… em cũng đủ hiểu rồi.” — cô khẽ nói, giọng run nhẹ.

Một khoảng im lặng.

“Anh đã giận… giận cả thế giới khi em ra đi. Nhưng rồi anh lao vào làm việc, bươn chải… chỉ để quên. Mà càng cố quên, lại càng nhớ.”

Hà Anh ngước nhìn anh. Đôi mắt ánh lên điều gì đó không thể gọi tên.

“Anh từng hứa… khi thành công sẽ tìm lại em. Giờ anh là tổng giám đốc một công ty IT. Anh đã trở về. Nhưng hôm biết em kết hôn… lòng anh như rơi xuống vực.”

Gió lại lùa qua. Cô khẽ rùng mình.

“Không phải ngẫu nhiên… anh mua căn hộ gần nhà em.” — Quân khẽ nói. “Anh chưa buông được. Chưa bao giờ thực sự buông.”

Họ ngồi thêm một lúc. Không nói gì nhiều, chỉ là vài chuyện vu vơ. Ánh mắt vẫn chạm nhau — đủ để tim rung lên, nhưng chưa đủ phá vỡ khoảng cách.

Lúc ra về, Quân đứng dậy trước. Hà Anh khẽ gật đầu, bước bên anh ra cửa quán. Gió chiều mát rượi.

“Anh đưa em về nhé?” — Quân hỏi, ánh mắt dịu dàng.

Hà Anh lắc đầu, mỉm cười. “Không cần đâu… Em đi bộ một đoạn cho nhẹ đầu.”

“Ừ…” — anh gật, không giấu được nỗi thất vọng lặng lẽ.

Họ đứng đó vài giây. Như muốn nói thêm điều gì. Nhưng rồi lại im lặng.

Chỉ một cái gật nhẹ — thay cho lời tạm biệt.

Họ quay đi. Mỗi người một hướng.

Nắng chiều rơi nghiêng, kéo dài bóng hai người về phía ngược nhau.

Trên đường về, Hà Anh nghe tim mình đập nhanh hơn bình thường. Một phần nhẹ nhõm. Một phần… trống trải.

Cuộc gặp ấy không có gì sai — nhưng cũng không hoàn toàn đúng.

Còn Quân, tay đút túi quần, mắt nhìn xuống mặt đường lấm tấm nắng. Cô vẫn đẹp như ngày xưa. Nhưng giờ… đã là của người khác.

Một cuộc gặp tưởng như vô hại — nhưng trong lòng mỗi người, lại như một dòng ngầm vừa thức dậy.
