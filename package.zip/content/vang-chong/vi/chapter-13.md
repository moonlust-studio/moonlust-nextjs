# Vắng Chồng – Chương 13

Cánh cửa phòng 302 vừa khép lại sau lưng Hà Anh. Cô lao vào Quân như lửa bén vào khô. Hơi thở cô gấp gáp, ngắt quãng, như vừa chạy băng qua một cơn bão cảm xúc. Hà Anh đẩy mạnh anh dựa sát vào cánh cửa, cánh tay siết chặt lấy cổ anh, môi cô ập vào như thể đã khao khát suốt bao đêm. Nụ hôn ngấu nghiến, ẩm ướt, rối loạn, mang theo cả sự uất nghẹn lẫn đam mê chất chồng.

Tiếng thở của cả hai hoà vào nhau – nặng nề, cháy bỏng, gấp đến mức Quân phải đưa tay giữ chặt eo cô để không gục xuống vì choáng. Hà Anh bất ngờ siết cổ anh chặt hơn, rồi vít đầu Quân xuống, áp mặt anh vào bầu ngực trần vừa được giải thoát khỏi lớp áo.

— "Hôn  em đi… mạnh vào…" – cô thì thầm như ra lệnh, mắt rực lên.

Quân úp mặt vào làn da thơm nồng mồ hôi ấy, đầu lưỡi mơn man bầu ngực đang phập phồng dữ dội. Tay anh run lên, ôm siết lấy lưng cô, còn Hà Anh thì rướn người, ấn sát anh hơn nữa – như thể muốn làm ngạt anh trong chính khát khao của mình.

Tay cô luồn vào áo anh, cào nhẹ sống lưng, rồi vòng ra trước – xé từng chiếc cúc áo như xé toạc mọi phòng bị cuối cùng. Cô không đợi được nữa. Mắt long lên, môi thở hổn hển, Hà Anh kéo áo mình qua đầu, để lộ làn da trần bóng mồ hôi, bầu ngực phập phồng như đang thở cùng những câu rên chưa thành tiếng. Tay cô không ngừng trượt xuống – từ cổ anh, qua bụng, rồi chạm vào cạp quần.

— "Không nói gì cả… hôm nay… em không muốn nghĩ nữa."

Rồi cô từ từ quỳ xuống. Đôi mắt ướt long lanh, vừa đầu hàng vừa khao khát. Ngón tay run nhẹ kéo khóa. Cậu nhỏ của Quân bật ra, cương cứng dữ dội, bóng loáng và nóng bỏng. Nhớ nó quá mất rồi, cô không chần chừ. Cô ngậm lấy anh – sâu, dứt khoát – như nuốt trọn nỗi nhớ và cơn điên của chính mình.

Đầu lưỡi cô quét nhẹ quanh vành khấc, rồi ấn xuống dưới, xoáy tròn như đang trêu đùa nỗi nhạy cảm của anh. Cô rút ra một chút, rồi lại ngậm vào sâu hơn, để môi mình căng ra vì chiều dài của anh. Những âm thanh ướt át vang lên nhịp nhàng, ướt sũng giữa hơi thở đứt đoạn. Có lúc cô dừng lại, liếm dọc thân cậu nhỏ từ gốc lên đỉnh, rồi mút chặt lấy đầu khấc, như muốn anh bắn ra ngay trong khoảnh khắc ấy.

Nhịp hút của cô gấp gáp, dồn dập, như đang rút cạn nỗi u uất bằng khoang miệng nóng ẩm. Quân không thể đứng yên nữa, hai tay anh bất giác đặt lên đầu Hà Anh, rồi siết chặt, nhẹ nhàng nhưng dứt khoát, đẩy đầu cô về phía trước theo từng nhịp anh nín thở.

— "Ngoan… bú sâu nữa đi… đúng rồi… Em biết anh nhớ em lắm không..."

— "Em nhớ mùi này… nhớ cái cảm giác này phát điên lên…"

Hà Anh rên nhẹ trong cổ họng, nhưng không lùi lại – cô để mặc anh giữ đầu mình, để chính anh điều khiển cơn cuồng loạn. Cổ cô căng ra, đôi mắt khép hờ mà miệng vẫn siết chặt cậu nhỏ, ra vào ướt át đến mê người.

Quân rên khẽ, rồi kéo mạnh hơn, dồn dập hơn, khiến đầu cô theo từng nhịp thúc sâu – ngập đến tận cuống họng.

— "Há miệng ra nào… anh muốn nhìn thấy nước miếng em dính đầy tình yêu anh…"

— "Nuốt nó như em đang nuốt lấy anh vậy… giỏi lắm… như thế này ai mà chịu nổi…"

Cô thở gấp, tiếng rên nhòe trong miệng đầy, hai tay cô bám vào đùi anh để giữ thăng bằng, nước mắt rưng rưng vì bị đẩy quá sâu – nhưng vẫn không hề dừng lại. Cô đảo lưỡi, mút chặt lấy từng phân thân như một nghi thức thờ phụng, như thể mỗi cú hút là một lời thú nhận đê mê không thể rút lại.

Quân choáng váng, cả người áp sát cửa, bàn tay đập nhẹ vào gỗ để giữ thăng bằng.

— "Trời ơi… Hà Anh… anh… không chịu nổi…"

— "Không cần chịu… cứ ra đi… trong em."

Và rồi… từng đợt trắng đục bắn vào miệng cô. Cô nhắm mắt, nuốt trọn. Khi lắng xuống, cô ngẩng lên, môi còn vương ướt, thì thầm:

— "Từ giờ… cứ để em hư hỏng trong vòng tay anh."

Quân đứng như hóa đá, hơi thở còn chưa lấy lại. Anh nhìn xuống người con gái đang quỳ dưới chân mình – mái tóc rối, đôi môi bóng ướt, ánh mắt ngẩng lên vừa thỏa mãn vừa điên dại. Một dòng tinh dịch còn vương nơi khóe miệng cô, và hình ảnh ấy khiến toàn thân anh rùng lên lần nữa.

— "Hà Anh… em vừa mới… làm anh muốn chết trong miệng em luôn đấy..."

Anh kéo cô đứng dậy, ôm siết lấy cô thật mạnh, tay run run xoa dọc sống lưng như để chắc chắn đây không phải mơ. Môi anh tìm xuống cổ cô, hôn lên từng điểm còn vương mùi mồ hôi nóng bỏng.

— "Lần sau… anh sẽ làm em không thở nổi… như em vừa làm anh."

Sau khi nuốt trọn từng giọt tinh dịch trong miệng, Hà Anh không để Quân kịp nghỉ ngơi. Cô kéo anh ngã xuống giường, leo lên người anh bằng một động tác dứt khoát, rồi thì thầm như rót mật vào tai:

— "Giờ tới lượt em… muốn dập theo cách của riêng mình."

Quân chưa kịp nói gì thì Hà Anh đã đưa tay nắm lấy cậu nhỏ – lúc này vừa mới xìu xuống một chút – rồi nhẹ nhàng mơn trớn. Chỉ vài giây sau, nó lại căng cứng, như thể sẵn sàng bước vào hiệp ba bất chấp mọi giới hạn sinh lý.

— "Anh thấy không… nó nhớ em mà…"

Cô nhích người lên, đưa tay tách nhẹ môi dưới của mình, rồi từ từ đặt lên đầu khấc, trượt vào từng chút một. Cảm giác được cô chủ động bao trọn lấy mình khiến Quân rên khẽ, hai tay vô thức đặt lên eo cô, nhưng cô gạt ra.

— "Không… để em làm… hôm nay em cưỡi anh… cho thoả hết những lần phải nằm im với chồng mà không bao giờ lên đỉnh."

Cô bắt đầu nhún. Nhịp điệu chậm rãi, êm ái – rồi nhanh dần, dập dồn. Hai tay đặt lên ngực Quân, đầu ngửa ra sau, mái tóc rối bù ướt mồ hôi lòa xòa trên lưng. Bầu ngực nảy lên theo từng cú nhấn – như muốn thiêu rụi mọi lý trí còn sót lại.

— "Anh nhìn đi… nhìn em cưỡi anh… em muốn khắc hình ảnh này vào đầu anh mãi mãi…"

Quân không kìm được nữa, anh bật người ngồi dậy, ôm cô vào lòng và bắt đầu phối hợp – cú thúc từ dưới lên kết hợp với cú nhún từ trên xuống khiến cả hai như tan vào nhau. Những tiếng rên bật ra không thể kìm nén. Mỗi cú thúc là một tiếng nước va chạm, ướt át, thô ráp, đắm say.

— "Em… em sắp… aahhh… Quân… giữ em lại…"

Và rồi, giữa nhịp chuyển động ấy, Hà Anh gồng người, cong lưng, siết chặt lấy anh – toàn thân cô co rút lại trong một cơn cực khoái trào lên đến tận óc. Cô run lên, nước mắt lăn dài, miệng vẫn gọi tên anh như một câu thần chú:

— "Quân… Quân… Quân…"

Quân cũng rên khẽ, cắn nhẹ vai cô, rồi bắn trọn vào sâu bên trong. Hà Anh không rời ra. Cô để yên như thế, gục đầu lên vai anh, cả hai cùng run rẩy, cùng thở hổn hển trong cơn khoái cảm chưa tan.

Một khoảng lặng bao trùm, chỉ còn tiếng tim đập và hơi thở đan xen.

— "Từ giờ… em sẽ là người cưỡi lên những ký ức cũ… để sống trọn với hiện tại này."

(Nằm nghỉ ngơi một lát sau hai hiệp bốc lửa, họ ôm nhau trao những lời yêu thương say đắm. Bàn tay Hà Anh vẫn nắm lấy cậu nhỏ của Quân như thể sợ nó biến mất.

Một lúc sau, Hà Anh thì thầm:

— "Mình tắm chung đi… em muốn rửa sạch những gì tội lỗi nhất… để bắt đầu phạm tội thêm lần nữa."

Quân khựng người. Anh chưa từng tắm chung với bất kỳ người phụ nữ nào. Chưa từng ai rủ anh như thể họ là người chủ động… như Hà Anh.

Cô kéo tay anh vào phòng tắm. Hơi nước ấm lan tỏa mờ ảo trên gương kính. Hà Anh cởi từng chiếc cúc áo cho anh, rồi nhẹ nhàng cởi luôn áo mình, để lại hai thân thể trần trụi soi vào nhau như trong gương.

— "Em rửa cho anh nhé… để mai này khi nhớ, em vẫn nhớ được từng thớ thịt nơi tay mình đã chạm."

Dưới vòi nước ấm, bàn tay mềm mại của Hà Anh chạm vào cậu nhỏ của Quân khiến anh không khỏi rùng mình. Ánh mắt cô nhìn anh vừa đắm đuối vừa đầy dâm đãng. Quân quàng tay kéo bờ mông tròn trịa, trắng mịn của Hà Anh lại gần, rồi không ai nói với ai, họ lại lao vào nhau trong một nụ hôn sâu đắm. Lưỡi quấn lấy nhau, tạo thành âm thanh ướt át, đầy nhục cảm.

Bàn tay Hà Anh vẫn sục nhẹ cậu nhỏ của Quân – lúc này đã cứng lên trở lại đầy mạnh mẽ. Quân không ngờ mình hồi phục nhanh đến thế sau hai lần xuất ra. Thấy vậy, Hà Anh cười khẽ – một nụ cười đầy bí ẩn và khiêu khích.

Hà Anh thở dốc, một tay bám lấy bức tường kính đẫm nước, tay còn lại kéo vòng tay anh ôm chặt hơn. Và rồi, Quân nhẹ nhàng tách hai chân cô, nhấc một chân đặt lên bệ tường thấp… và bắt đầu tiến vào từ phía sau – chậm rãi, sâu, và đầy quyết liệt.

Cả phòng tắm giờ chỉ còn lại tiếng nước rơi và tiếng da thịt va vào nhau, nhịp điệu mỗi lúc một dồn dập. Hà Anh rên khẽ, rồi bật ra tiếng thở dài nức nở – vừa đau, vừa sướng, vừa buông xuôi tất cả những gì gọi là đạo đức cuối cùng.

Trong gương mờ, hình ảnh hai thân thể quấn chặt lấy nhau như hòa vào làm một – ướt át, run rẩy, và đầy tội lỗi.

— "Mạnh nữa đi… sâu nữa… em muốn tan chảy trong anh…"

Quân không ngừng nhấp – sâu, chắc, dứt khoát – mỗi cú thúc là một lời khẳng định rằng: em giờ đã là của anh.

— "Chồng em có làm em rên như thế này không?"

— "Nói đi… ai khiến em phát điên hơn?"

Hà Anh không trả lời. Cô chỉ siết chặt tay anh, ngẩng đầu lên và rên khẽ trong tiếng nước xối. Giữa hơi nước mờ ảo và mùi da thịt quện vào nhau, Hà Anh biết… cô đã hoàn toàn mất phương hướng. Mọi ranh giới đã vỡ tan như bọt nước dưới chân họ.
