Chương 12 Trong Vòng Tay Chồng, Ngoài Nhịp con tim

"Có những lúc, em vẫn nằm ngoan ngoãn trong vòng tay anh… nhưng trái tim thì đã lang thang nơi khác từ lâu."

Căn phòng ngủ vẫn vậy – chiếc giường cưới cũ, mùi vải thơm từ ga trải giường, ánh đèn ngủ vàng dịu hắt xuống tấm lưng trần của Hà Anh. Chồng cô – vừa trở về sau hai tháng công tác – đang ngủ say, hơi thở nặng nề và đều đặn. Trên bụng anh, từng vệt mồ hôi còn đọng lại sau cuộc ân ái vừa rồi. Một cuộc yêu… đủ đầy, đúng nghĩa vợ chồng.

Nhưng sao trong lòng cô lại trống hoác đến thế? Hà Anh quay người, kéo nhẹ tấm chăn lên ngực. Cô không ngủ được. Đôi mắt vẫn mở trừng trong bóng tối. Ngoài cửa sổ, tiếng mưa rơi lộp độp trên mái tôn, gió lùa qua khe cửa tạo thành những âm thanh rì rào – như tiếng nức nở thầm lặng trong tâm hồn.

Ký ức về Quân – về những ngày vụng trộm, làn môi nóng bỏng dọc sống lưng, cái ôm từ phía sau khiến cô nghẹt thở – hiện lên như thước phim quay chậm, len lỏi qua từng hơi thở.

Với chồng, mọi thứ là thói quen. Từ cách ôm đến cách chạm. Không có gì sai – nhưng cũng chẳng còn gì khiến tim cô rung động. Không còn sự bất ngờ. Không còn cái cảm giác ngây dại khi một đầu ngón tay lướt qua da thịt.

— "Em mệt à?" – giọng chồng vang lên lơ mơ.  
— "Không… Em chỉ hơi khó ngủ thôi."  

Anh xoay người ôm cô từ phía sau. Một cái ôm quen thuộc. Cánh tay vòng qua eo, chân gác lên đùi cô. Cơ thể ấm, nhịp thở đều. Nhưng chính lúc ấy – trong vòng tay chồng – Hà Anh lại thấy mình lạnh buốt.

Cô nhắm mắt. Trong bóng tối, cô tưởng tượng mình đang ở căn phòng khách sạn cũ, nơi Quân từng thì thầm:  
— "Em không cần phải giỏi chịu đựng như thế. Ở đây… chỉ cần thở thôi cũng đủ khiến anh muốn chiếm lấy rồi."

Một giọt nước chảy từ khóe mắt xuống gối. Không rõ là nước mắt… hay mồ hôi.

Bàn tay chồng bất chợt chạm vào nơi mềm mại giữa hai chân. Hà Anh khẽ giật mình, nhưng vẫn im lặng. Anh vuốt nhẹ vùng lông mu mịn màng, rồi chậm rãi đưa ngón tay lướt qua khe ướt. Cô không cưỡng lại. Mọi chuyển động cứ diễn ra như kịch bản quen thuộc – một vở diễn không lời, nơi diễn viên không còn nhập vai.

Anh yêu cô – chậm rãi, nhịp nhàng, như một người chồng lâu ngày xa vợ. Nhưng Hà Anh thì đã trôi đi nơi khác. Ý thức cô dần tách rời khỏi thực tại, dạt vào ký ức. Cô cắn môi, ngăn tiếng rên. Không phải vì khoái cảm. Mà vì tội lỗi.

Khi mọi thứ kết thúc, khi anh ngủ lại trong tiếng thở đều, cô vẫn nằm đó – mắt mở to, tim thổn thức.

"Em vẫn là vợ anh. Nhưng tâm hồn em… đã không còn ở đây nữa."

Sáng hôm sau, Hà Anh ngồi một mình ngoài ban công, tay cầm ly cà phê đen nhạt. Ánh nắng đầu ngày len qua tán cây, phản chiếu trên làn tóc rối. Tiếng chim sẻ hót lẫn trong tiếng còi xe tạo nên một thứ âm thanh nửa quen, nửa lạc lõng.

Điện thoại rung nhẹ. [Quân: Em ổn không?] Hà Anh nhìn dòng tin. Không trả lời ngay. Xóa đi… rồi gõ lại.  
[Ổn.] Chỉ một chữ. Nhưng trong lòng, là nghìn mảnh vỡ.

Chồng cô bước ra, đặt tay lên vai:  
— "Hôm nay mình đi ăn với ba mẹ nhé. Ông bà nhớ cu Minh."  

Cô gật đầu, cười nhẹ. Nhưng tay vẫn nắm chặt điện thoại – như đang giữ lấy một điều gì đó sắp tuột khỏi tầm với.

Cô gắng hòa nhịp với vai người vợ yêu chồng, từng câu rên, từng động tác khẩu dâm đều được lặp lại như lời thoại. Nhưng trong lòng – là khoảng trống.

Hà Anh chỉ có thể lên đỉnh khi anh đặt cô vào tư thế doggy cạnh bệ bếp. Cô nhắm chặt mắt, miệng thở hổn hển trong mê dại. Nhưng người cô tưởng tượng không phải chồng… mà là Quân.

Tiếng rên càng lúc càng dồn dập, và trong một khoảnh khắc mất kiểm soát, cô suýt thốt lên:  
"Quân… ơi…"

Lần duy nhất cô lên đỉnh – là khi trí nhớ đưa cô về với người ấy.

Cô cũng bắt đầu nhận ra… chồng đã khác. Những tư thế trước kia chưa từng thử – giờ lại trở nên thường xuyên.

Anh muốn cô ngồi lên mặt anh, để môi anh ngấu nghiến mật ngọt từ nơi sâu kín. Có lần, chồng ép cô chống tay vào cửa sổ, kéo tóc, vỗ vào mông – những hành động bản năng, hoang dại.

Cô có sướng – nhưng là cái sướng đi kèm nỗi nghi ngờ.  
"*Có phải ở nước ngoài… anh cũng từng chạm vào ai đó?*"

Ký ức ùa về… Đêm tân hôn – anh run rẩy tháo từng chiếc cúc áo của cô. Tay vụng về, mắt không dám nhìn lâu vào ngực cô, chỉ siết tay lại, thì thầm rằng:  
— “Anh sẽ nhẹ nhàng… Anh chỉ muốn em không thấy đau.”

Hà Anh khi đó vừa bối rối, vừa hạnh phúc. Mọi chuyển động đều chậm rãi, ấm áp – như thể anh đang sợ làm vỡ một đóa hoa.

Nhưng bây giờ, cùng là người đàn ông ấy… lại đẩy cô sát vào cửa sổ, kéo tóc, thì thầm những câu khẩu dâm khiến cô thấy bối rối hơn là kích thích.

Cô không biết từ khi nào sự dịu dàng biến mất. Và cô cũng không rõ – liệu những thứ mới lạ đó… có phải là điều mà người khác đã dạy anh?

Chính cô cũng giằng xé. Chồng là người đầu tiên, là người tốt – nhưng cơ thể cô thì không còn thuộc về anh.

Nơi sâu thẳm ấy luôn ẩm mềm, luôn khao khát điều gì đó mạnh hơn, dày vò hơn… thứ mà Quân từng trao.

Vài ngày sau.

Buổi sáng âm u, mưa phùn lất phất. Đường trơn, xe cộ lướt qua như những cái bóng.

Chồng xách vali. Hà Anh tiễn anh bằng cái ôm dài, một nụ hôn nhẹ và đôi mắt thâm quầng vì mất ngủ.

Đêm qua, chồng cô đã hì hục nhấp cô cả đêm, đủ các tư thế hoang dại nhất có thể.

— "Anh đi cẩn thận nhé… Em và con sẽ ổn." – Hà Anh nói với chồng.

Xe khuất dần sau khúc cua.

Hà Anh quay bước thật nhanh – gần như chạy – về khu chung cư phía sau công ty.

Tầng ba. Phòng 302.

Tay run run khi bấm mã khóa.

Cửa mở.

Không lời.

Không chờ đợi.

Cô lao vào – đẩy Quân dựa lưng vào cánh cửa.

Tiếng "rầm" vang lên như hồi chuông kết thúc một vai diễn, và mở ra một vở kịch khác – nơi cô không còn là vợ ai cả.

— "Hà… Hà Anh… Em…"