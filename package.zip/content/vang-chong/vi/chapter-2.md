“Anh đã bao giờ tò mò, một phần trong em vẫn đợi anh trở về?” — câu hỏi ấy vừa thoáng lướt qua trong tâm trí Hà Anh, rồi tan như khói trà chiều. Quân. Cái tên bật lên trong đầu cô như một nhịp vang trầm, từ đâu đó trong lớp ký ức phủ bụi vừa khẽ rung lên giữa lồng ngực. Một cảm giác lạ lẫm mà thân thuộc, như thể một cơn gió đã từng rất quen đang vô tình lướt qua vùng da mỏng phía sau gáy.

Anh vẫn vậy — cao, gầy, khuôn mặt mang nét từng trải, như đã dừng lại ở nơi nào đó của thời gian. Nhưng đôi mắt… vẫn là đôi mắt năm xưa — trầm tĩnh, sâu thẳm, và dịu dàng đến độ khiến người ta muốn ngoảnh mặt đi để khỏi chênh vênh.

Hà Anh khẽ lùi nửa bước, ngón tay siết nhẹ quai túi — vô thức, như thể đang cố níu một điểm tựa mong manh trong lòng phố thị.

"Lâu quá rồi nhỉ…" — giọng anh khàn, trầm, pha một chút buông lơi của người từng rất gần… rồi rất xa.

Hà Anh gật đầu, nụ cười nghiêng nhẹ. Không giấu được chút ngại ngần, chút lúng túng — như một vết xước cũ vừa lộ ra dưới ánh sáng.

Họ từng yêu nhau. Một mối tình sinh viên đẹp như nắng đầu hè — rực rỡ, chân thành, và không toan tính. Nhưng rồi, hiện thực phũ phàng hơn cổ tích.

Gia đình Hà Anh không chấp nhận một chàng trai tỉnh lẻ nghèo. Mẹ cô từng lạnh lùng: "Tình yêu không nuôi nổi con. Con gái mẹ không thể sống bằng cảm xúc."

Quân không trách ai. Chỉ trách mình — vì không đủ mạnh mẽ để giữ lấy cô.

Hà Anh, dẫu yêu đến nhức nhối, vẫn buông tay — vì cô biết mình không đủ can đảm để đi ngược lại số phận.

Họ rời xa không phải vì hết yêu, mà vì bị đời buộc phải quên nhau sớm hơn trái tim cho phép.

Ngày tốt nghiệp, Quân rời thành phố. Không từ biệt. Không tin nhắn. Hà Anh không tìm anh. Cô hiểu — nếu gặp lại, sẽ chẳng đủ lý trí để rời xa lần nữa.

Những tưởng đã lãng quên. Nhưng rồi, dưới ánh đèn siêu thị hôm ấy — giữa quầy rau củ xào xạc — ánh mắt họ lại chạm nhau. Và tất cả… ùa về như một đợt gió chướng đầu mùa.

Không phải yêu. Cũng chẳng hẳn tiếc. Mà là cảm giác lưng chừng — chỉ một thoáng thôi, cũng đủ khiến tim co lại.

"Anh mới chuyển đến gần đây, cách hai tòa thôi." — giọng anh vẫn trầm. Ánh mắt chưa rời cô lấy một giây.

Hà Anh mỉm cười. Cố giấu đi nhịp tim đang lạc một nửa. Rồi như để kết thúc cuộc chạm mặt bất ngờ, cô quay đi. Nhưng sau lưng, ánh nhìn ấy vẫn ở lại. Nhẹ nhàng. Dai dẳng.

Đêm ấy, Hà Anh nằm nghiêng. Ánh đèn ngủ hắt bóng lên bờ vai trắng mịn, mỏng như tấm lụa mưa đầu hạ. Không phim. Không điện thoại. Chỉ có khoảng không mờ xám bên ngoài khung cửa — yên lặng đến nỗi, cô nghe được cả tiếng thở dài của mình.

Ngoài trời, mưa lất phất. Mùi đất ẩm thoảng qua khe cửa sổ, quấn lấy không gian như một làn hơi quá khứ. Hương đêm ẩm mát đậu lên tóc, lên cổ, gợi nhớ những lần vai kề vai bên nhau năm nào.

Sao một cuộc gặp thoáng qua lại khiến lòng chao đảo đến thế? Là ánh mắt anh? Là giọng nói xưa cũ? Hay là… chính cô đã quá mỏi mệt với cô đơn?

Trong ngực, một vết rạn khẽ lan rộng. Lý trí giữ cô bên bờ vai quen thuộc của hôn nhân. Nhưng cơ thể — như khối tro tàn âm ỉ — vừa lén nhích lên một hơi thở. Đủ để khiến cô nhận ra, mình đã lạnh quá lâu.

Ký ức lại đưa cô về thời sinh viên. Khi Hà Anh mới đôi mươi, hay cười và mơ nhiều. Quân là người đầu tiên dắt cô qua những con phố mưa khuya, là người đầu tiên trao nụ hôn dưới tán cây ướt sương.

Những cái nắm tay — nhẹ thôi — nhưng đủ khiến tim cô không còn là của riêng mình.

Anh từng nói: "Anh không có gì ngoài một trái tim đủ rộng để yêu em đến tận cùng." Câu nói ấy, sau này mỗi khi cô nhớ lại, vẫn khiến lòng dâng lên một vị mặn khó gọi tên.

Cô trở mình. Ngón tay lặng lẽ mở ngăn kéo nhỏ — nơi cất chiếc hộp nhung đen đã cũ. Mỗi lần chạm vào, như chạm vào một nhịp tim xưa vẫn lặng lẽ đập trong cô.

Đêm nay, cô mở nó. Không phải vì hoài niệm. Mà vì trái tim — đang siết lại bởi một khoảng trống không tên.

Nắp bật khẽ. Như một tiếng thì thầm.

Điện thoại sáng lên. Tin nhắn từ Quân: “Mai em có rảnh không? Anh mời cà phê. Gọi là bù cho cái va chạm siêu thị.”

Cô nhìn màn hình. Tim chệch nhịp. Một phút… rồi hai. Cô chưa trả lời.

Nhưng trong đầu, thước phim cũ đã lặng lẽ tua lại. Không mờ. Không cũ. Và chẳng phải quá khứ.

Là hiện tại. Và có lẽ… là cơn gió đầu tiên của một mùa đắm say đang lặng lẽ kéo về.