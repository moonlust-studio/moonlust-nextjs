Chương 6: Từ Một Cái Chạm Nhẹ 

"Không phải cái ôm nào cũng là để yêu. Có cái ôm... chỉ là để một người đàn bà thôi không thấy mình sắp đổ vỡ."

Tin nhắn cuối cùng Hà Anh gửi đi — “Em chưa bao giờ quên” — được Quân phản hồi sau một đêm dài im lặng.
“Nếu có một ngày em muốn quên giới hạn... Anh vẫn sẽ ở đó. Chỉ để lắng nghe. Chỉ để ôm.”
Không thêm một lời.

Sáng hôm sau, Hà Anh nhìn tin nhắn ấy rất lâu. Không trả lời. Nhưng cũng không xóa.
Chiều muộn hôm đó, trời u ám như thể mang trong mình một nỗi buồn không tên. Gió thổi rì rào qua những tán cây bên hồ. Lá vàng rụng như từng ký ức cũ buông mình lặng lẽ.

Hà Anh nhắn cho Quân một dòng ngắn gọn:
“Em có chuyện cần nói. Gặp anh được không?”
Họ hẹn nhau ở một quán café ven hồ. Mưa bắt đầu lất phất như tiếng thì thầm của lòng người.

Hà Anh đến muộn. Không trang điểm. Váy len dài, kín đáo. Nhưng ánh mắt cô khác – như đang cất giấu một vùng nước lớn sắp tràn bờ.
Cô ngồi xuống. Không gọi nước. Chỉ khẽ nói:
“Tối hôm đó... em sai. Em không nên nhắn như thế.”
Quân im lặng. Nhìn cô rất lâu, rồi khẽ lắc đầu:
“Không. Em không sai. Em chỉ… nói thật lòng mình. Mà đôi khi, nói thật lòng… lại là điều khó nhất.”

Trời bắt đầu đổ mưa. Những giọt đầu tiên rơi nhẹ lên mặt kính, kéo dài thành vệt mờ như những dòng ký ức trượt xuống.
“Anh đưa em về.” – Quân đứng dậy.

Trên đường, mưa nặng hạt. Đến ngã tư, đèn đỏ kéo dài. Âm thanh xe cộ loang loáng trong màn mưa như nhấn chìm họ giữa ranh giới đúng – sai.
Quân khẽ nói, giọng trầm mà nhẹ như gió lùa qua ô cửa:
“Nếu muốn, gần đây có chỗ trú mưa… Mình có thể vào tạm, chờ trời dịu lại rồi hẵng đi tiếp.”

Hà Anh không đáp. Cô nhìn mưa, nhìn tay mình siết quai túi, rồi liếc sang Quân. Trong khoảnh khắc đó, có điều gì đó trong cô khẽ nứt.
Cô không gật. Cũng không lắc. Chỉ khẽ quay mặt đi, giọng rất khẽ:
“Ừ... trời mưa mà.”

🌧️ Khách sạn. Ánh đèn. Và khoảng cách mờ ranh giới.

Căn phòng đơn giản, sạch sẽ. Không sang trọng. Nhưng đủ yên tĩnh để nghe rõ tiếng tim đập.
Ánh đèn vàng phủ khắp, tạo không gian mơ hồ — nơi lý trí bắt đầu nhường chỗ cho cảm xúc.
Do bị mưa, Hà Anh quấn nhẹ khăn tắm quanh người. Quân tựa vào bàn, nhìn cô. Ánh mắt không còn bỡn cợt, mà là một nỗi khao khát chín muồi.

“Vào đây… thấy nhớ cái phòng trọ cũ ngày xưa ghê.” – Quân cười khẽ.
Hà Anh nhìn anh, vừa ngỡ ngàng, vừa như bị kéo về một miền ký ức:
“Căn phòng hồi sinh viên… chật mà lúc nào cũng ồn ào tiếng guitar với mì gói.”
Quân tiến lại gần:
“Hồi đó em lúc nào cũng mặc áo phông rộng với quần short. Vậy mà anh thấy… còn hấp dẫn hơn bây giờ.”
Hà Anh đánh nhẹ vào tay anh, ngượng ngùng. Nhưng ánh mắt cô lại không giấu được sự rung động.

“Anh nhớ không gian đó. Cảm giác chỉ cần kéo em vào lòng, là cả thế giới biến mất…”
Cô im lặng. Mắt hướng về phía khung cửa. Rồi bước lùi nhẹ, để mình chạm dần vào bầu trời giông bão phía ngoài.

Trong đầu cô vẫn hiện lên suy nghĩ: mình đã có chồng con. Quân chỉ là người cũ. Vào đây chỉ vì tránh mưa mà thôi.
Một tia chớp lóe ngoài cửa, kéo theo tiếng sấm trầm như tiếng gọi từ sâu thẳm.
Quân tiến lại gần, lặng lẽ đặt tay lên eo cô — chậm rãi siết lại như một bản năng không kìm được.

Cô giật mình. Muốn đẩy anh ra. Muốn bước khỏi căn phòng này trước khi không thể quay đầu.
Nhưng rồi… những kỷ niệm cũ tràn về, kéo cô ở lại.
Quân hít hà mái tóc mềm. Hơi thở anh nóng rực bên cổ cô. Môi anh lần xuống từng đốt sống – từ gáy, trượt dần xuống.
Tay anh siết chặt eo cô – như không muốn để cô biến mất thêm lần nào nữa.
Gió bất ngờ hắt tung rèm cửa, khiến khăn trên vai cô lay động — như chính lòng cô cũng vừa run lên.

Anh xoay nhẹ người cô lại, đối diện. Ánh mắt họ va nhau. Một khoảng lặng sâu.
Quân cúi xuống. Nụ hôn đầu chạm vào khóe môi cô — nhẹ như cánh chuồn chuồn đậu.
Nhưng rồi, khi Hà Anh không né tránh, anh hôn sâu hơn. Một nụ hôn bị dồn nén — run rẩy, mãnh liệt, như sợ không còn cơ hội nào khác.

Tay anh chạm lên cánh tay cô, trượt lên vai. Ngón tay tìm mép khăn tắm. Khi cảm nhận được hơi thở gấp gáp của cô, anh dừng lại – ánh mắt hỏi ý.
Hà Anh không đáp. Chỉ khẽ nhắm mắt.
Chiếc khăn tuột dần. Từng centimet vải kéo theo từng lớp phòng vệ cuối cùng.
Tay anh mơn trớn nhẹ, vuốt ve làn da mềm mại đã quá lâu không được ai chạm đến.
Quân quỳ xuống. Nhẹ nâng gót chân cô. Hôn lên đầu gối. Rồi hôn dọc đùi trong – chậm, sâu, mê đắm.

Hà Anh run lên.
“Quân… đừng nhìn em như thế…” – cô khẽ rên, vừa xấu hổ, vừa khao khát.
Điện thoại rung lên. Tên chồng hiện sáng màn hình.
Cô giật mình quay đi. Quân vẫn giữ nguyên vị trí, hơi thở ấm nóng phả lên đùi non, như một dòng điện chạy xuyên tế bào.

Cô quấn khăn chặt hơn, bước vội ra cửa sổ và bắt máy.
Ngoài kia mưa vẫn rơi. Trong phòng, ánh sáng vàng đổ lên làn da ẩm nóng.
Một tiếng sét xé bầu trời, khiến cô rùng mình — không rõ vì sợ… hay vì điều gì đó sâu kín hơn.

Giọng chồng vang lên: “Em đang làm gì đấy? Ở nhà với con à?”
“Ừ... em… em đang xem tivi thôi.” – cô nói, môi run, giọng như lạc giữa hai cơn sóng.
Nhưng Quân thì đang tiến lại từ phía sau. Từng bước hòa vào tiếng mưa.

Anh nhẹ nhàng đặt tay lên eo cô — rồi siết lại. Cơ thể anh áp vào lưng cô — tấm lưng trần chỉ được che bởi lớp khăn tắm mỏng.
Phía dưới… có một thứ đang cứng lên, tì sát lấy mông cô.
Hà Anh nín thở. Cầm máy chặt hơn.
“Em vẫn nghe đây…” – cô thì thầm, giọng mụ mị, như bám víu vào điều cuối cùng.
Tay Quân luồn lên bụng dưới. Rồi dừng lại, chờ đợi.

Tâm trí cô hoảng loạn. Nhưng cơ thể lại thổn thức. Cô biết, nếu không ngăn… Quân sẽ tiếp tục. Và cô cũng không muốn anh dừng.
Chồng cô nói gì đó. Nhưng cô không còn nghe rõ.
Một nhịp im lặng dài. Rồi cô khẽ nói:
“Thôi… mình nói sau nhé, con chắc đang gọi.”

Cô tắt máy.
Khoảnh khắc ấy, mọi ranh giới sụp đổ.
Cô buông điện thoại. Không quay lại. Nhưng không cản Quân.
Anh hiểu. Rất rõ.
Anh cúi xuống. Hôn lên lưng cô. Rồi vai. Rồi cổ.
Khi môi anh trượt xuống bờ vai trần run rẩy, Hà Anh nhắm mắt lại… và để mặc bản thân tan chảy giữa tiếng mưa – và tiếng lòng không còn lối quay về.