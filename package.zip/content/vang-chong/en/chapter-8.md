# Chapter 8 – Sleepless Night

📖 **Teaser:** When the body speaks, the soul can no longer remain silent.  
🎧 **Tagline:** Lust is loudest when whispered through the skin.

---

Ha Anh lay on her side, her messy hair spilling down her bare back. The warm yellow light of the bedside lamp cast a glow over her flushed skin, still steeped in the breath of passion.

Quan was behind her, his arm wrapped securely around her waist. His breathing was deep and even—but his eyes remained open, as if trying to memorize each trembling moment just passed.

She wasn’t asleep. Her body was still tingling, but inside… it felt like a flood was rising—wild and unstoppable.

Her hand reached back, touching his. Then she turned her head, a tiny, mischievous smile tugging at her lips:

"Do you want more?"

Quan looked at her. No words. But his eyes—lit up like fire.

He rolled her onto her back, leaning down to kiss her breast that had only just calmed.

“You already know the answer.”

This time, it was Ha Anh who took the lead. She wrapped her legs around his waist, pulling him close. Her hand reached down, grasping his hardness—warm, full, pulsing—and guided it to her lips.

She kissed the tip as if caressing something sacred. Her tongue traced his length, her eyes locked on his—teasing, seductive.

Quan let out a low moan, his body taut. He gripped the sheet as her tongue played around the vein that ran beneath, then slowly, gradually, took him into her mouth—deeper, deeper—until she reached the base.

"Where did you learn this...?” he whispered, gasping and moaning.

“Not from my husband,” she smirked—half teasing, half true—then continued, taking him in again, slower this time, in a rhythm soft and hypnotic, like a lullaby for lust.

Wet sounds filled the quiet room. Moans mingled with suckling, breath hot and heavy.

Just when Quan thought he might lose control, she stopped—climbed on top of him, pinned his hands above his head, and slid down.

As he entered from below, she let out a shuddering moan of fulfillment:

“Ah… god… it’s so deep… I love it…”

She began to move—slow at first, then faster. Her breasts bounced with each thrust. Sweat glistened on her neck, chest, stomach—the light catching her like a glowing silhouette in the dark.

“My husband’s never seen me like this…” she hissed, then leaned down and bit his ear. “Do you know… how long I’ve craved this feeling?”

Quan flipped her over, lifted her legs onto his shoulders—and pounded. Hard. Relentless.

The wet slaps echoed, blending with panting breaths and Ha Anh’s sobbing moans:

"So deep… ah… yes… don’t stop… more…”

They changed positions again and again—she on all fours, he taking her from behind; then lying sideways, one leg lifted for deeper thrusts; then she sat on him in a chair, arms wrapped around his neck—her back arched, chest pressed against his, their bodies moving in perfect rhythm.

“Right there… yes… harder… don’t you dare go easy on me tonight…”

Each climax brought tears—of not pain, but release. A wave of ecstasy stripping away her every facade.

No longer the cold wife. No longer the perfect mother. Just a woman—aching to be seen, to be touched, to melt in the arms of someone who truly listened to her body.

“Quan… I… again… don’t stop… don’t…”

“Moan for me, Ha Anh… let me hear everything you’ve kept buried…”

That night, they made love a third time, a fourth… they stopped counting. She drifted off, only to be awakened again by a kiss between her thighs.

She smiled through her tears. Moaned his name. And as dawn crept in, with the storm outside finally quieting… they were still tangled in each other.

Before the final round, Ha Anh leaned in, whispering into his ear with a trembling but eager voice:

“This time… I want it… in my mouth. Let me taste you… please.”

The words incinerated whatever reason Quan had left.

He panted, lifted himself, letting her lie back with her head slightly raised.

Standing by the bed, he watched as Ha Anh opened her lips—eyes gleaming, tongue tracing around his swollen tip—then took him in.

Quan grabbed her hair, moaning out loud:

"God… Ha Anh… I’ve dreamed of this since college…”

She sucked deeply, rhythmically—saliva and heat combining into wet, obscene music.

She reached up, using both hands and lips, making his whole body tense, every vein prominent.

Her soft moans hummed through him—like a desperate, rising melody.

“More… I can’t hold it… ah…”

And then—with a guttural moan and a strained cry of her name—Quan convulsed, holding her head in place… and came.

Pulse after pulse of thick heat filled her mouth, coated her tongue, slipped down her throat.

Ha Anh didn’t flinch. She swallowed—slowly, fully—then exhaled a soft, satisfied sigh:

"Salty… but it tastes like the man I never want to lose."

Quan pulled her into his arms, holding her as if giving her every last piece of himself.

They melted into one another—no clocks, no storm, no outside world. Only two hearts, beating as one.

Tonight, her body had truly come alive. And that buried voice… had finally been heard.
