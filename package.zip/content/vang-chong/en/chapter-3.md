
She had no idea when she drifted off that night — her mind a whirlpool of tangled emotions. Her heart, a knotted mess. Her body, strangely hollow… and damp.

Outside, the night breeze rustled through the trees, whispering like voices from a long-lost memory. Streetlights cast blurred shadows across the ceiling, as hazy as her thoughts.

In her dream, she was making love to her husband — wild, intense. Yet the man’s face began to blur… until it wasn’t her husband anymore. It was Quan. His deep, burning eyes seared through her.

She tried to resist, but her body followed each breath, each longing moan.

She woke with sweat across her brow — and between her thighs. The dream had left its mark. A dream… or a buried desire clawing its way out?

Morning crept in. Soft light filtered through the curtain slits, casting a gentle blush across her bedsheet. The lingering scent of fabric and her hair from the night before still clung to the air — faint and familiar, like the warmth of a dream that hadn’t yet faded.

Quan’s message resurfaced in her mind:

“If you’re free this afternoon… I want to see you. Just once.”

She didn’t answer. Part of her wanted to delete it — to erase the past. But another part… wanted to see him. Not to rekindle anything, but to ask. To look into his eyes and see if something was still left unsaid.

Sunlight filtered through the leaves outside, dancing across the swaying white curtain. The faint scent of jasmine from the diffuser floated in the air, thin as a memory. The room was so quiet, she could hear her own soft breathing.

She picked up her phone, then set it down again. Her thoughts circled: I’m married… Would meeting him cross a line? Or is it just a conversation?

A moment’s hesitation. Then those eyes — Quan’s eyes — appeared clearly in her mind, the same eyes that once made her heart skip.

She couldn’t delete it. Not yet.

She sat there in silence for a long while. Memories came flooding back. Their college days — a love once thought unbreakable. But distance, family, choices… had pulled them apart.

Tears welled in her eyes. Not sobbing — just quiet drops. Regret. Fear. Powerlessness. She knew that if she saw him again, it would be hard to keep her feelings in check.

But then she whispered to herself, like a gentle self-convincing:

“It’s just an old friend, that’s all…”

And then… she texted back:

“Why do you still have my number?”

The message sent. A moment later, her screen lit up.

“I never deleted it.”

Just four words. But they struck deep, tapping something inside her she thought long buried.

That afternoon, they met at a riverside café — the same one they used to frequent during college.

It was a small place, carrying the scent of roasted coffee and aged wood. Rustic tables and chairs, paint chipped with time. A pot of bougainvillea fluttered gently in the breeze.

Ha Anh arrived first. She chose a table on the patio. The setting sun cast a golden hue on her hair, on the rim of her glass as she slowly turned it in her hand.

Then Quan appeared.

Still tall, with that quietly melancholic gaze. His white shirt slightly wrinkled. He paused when he saw her — as if afraid the moment might vanish.

Their eyes met. No words. Just heartbeats and silence.

“It’s been a while…” — he finally said, voice low, almost lost in the wind.

“Yeah… a long time.” — she replied, trying to keep her tone even.

A breeze passed. The scent of coffee and wood stirred old memories.

“I used to imagine… if we met again, I’d say so much. But now… I don’t know where to start.”

“Just seeing you like this… I already understand,” she whispered, her voice trembling.

Silence again.

“I was angry… at the world when you left. I buried myself in work, chasing things to forget. But the harder I tried, the clearer your memory became.”

She looked up at him. Something unnamed flickered in her eyes.

“I promised myself — if I ever made it, I’d find you again. Now I’m the CEO of an IT company. I came back. But when I heard you got married… it felt like falling into an abyss.”

The wind brushed past. She shivered slightly.

“It wasn’t a coincidence… me buying an apartment near yours,” Quan said softly. “I haven’t let go. I never truly did.”

They sat a while longer. Talking little. Saying nothing deep. But their eyes kept meeting — enough to stir the heart, but not enough to close the distance.

When it was time to leave, Quan stood first. Ha Anh nodded, walking beside him toward the exit. The evening breeze cooled the air.

“I’ll walk you home?” — he asked gently.

She shook her head with a faint smile. “No… I’ll walk a bit on my own. Clear my head.”

“Alright…” — he nodded, the quiet disappointment unhidden.

They stood there a few seconds. As if words lingered, unspoken. But in the end, silence won.

A single nod — their farewell.

They turned. Each walking a different way.

The slanting sun stretched their shadows in opposite directions.

On her way home, Ha Anh felt her heart beating faster than usual. A mix of relief… and hollowness.

Nothing wrong had happened — but it wasn’t entirely right either.

And Quan, hands in his pockets, eyes on the sun-speckled pavement. She was still as beautiful as ever. But now… she belonged to someone else.

A meeting that seemed harmless — but within them both, a dormant current had been stirred awake.

A meeting that seemed harmless —  
but within them both,  
a dormant current had been stirred awake.
