
Morning came gently, sunlight filtering through the curtains like a shy afterthought of the night before. Ha Anh opened her eyes—naked, sore, and tangled in a storm of emotions. It had been ages since she’d slept that deeply—no dreams, no tossing. Only the afterglow on her skin and the musky scent of two bodies woven into the sheets.

She turned—slowly. A dull ache pulsed between her legs, drawing a sharp inhale from her lips. Her muscles protested with every slight shift, as if her body were still whispering remnants of last night.

Beside her lay a small folded note, written in that familiar, confident hand:

> You are most beautiful when you stop hiding what you truly desire.  
> I know this is crossing a line. But when you cried in my arms last night—I couldn't walk away anymore.  
> I’ve never touched a married woman before. But with you… every principle collapsed.  
> I didn’t come back to stir up your world. I came back… because staying away felt more like betrayal.  
> —Quan

She clutched the note, closed her eyes. Each line pressed into her chest like hot ink on delicate paper.

No, she didn’t regret it. But something inside her had shifted. Something she couldn’t name—like a thread that had always held her together had now quietly snapped.

She laughed, low and breathy:  
“Don’t even know how many rounds… no wonder my legs feel like jelly.”  
Then she smirked—a wicked little glint in her eye.  
“And yeah… Quan isn’t my husband.”

Back home, she soaked under the shower for ages. Cold water ran down her flushed skin, but it couldn’t erase the imprints of his hands, the fevered kisses, the way her breath had caught in his mouth.

In the mirror, she met her own gaze—red-rimmed, distant. As if seeing a version of herself she hadn’t met in years. Guilt coiled low in her belly. Her husband’s face floated behind the fog—gentle, unshaken. A man who had never failed her. Never raised his voice. Never left.

He was the one who stayed up when their child had a fever. Who ordered her favorite takeout after her late shifts. Who kissed her forehead without asking for anything in return.

She remembered the way he waved at the airport, smiling through tired eyes. And just like that—her heart twisted.

Why now, Quan?  
Why did you have to return when I was this lonely… this fragile?  
If we had just been braver back then—would I be sneaking around now, breathing in guilt between pleasure?

Tears gathered at the corners of her eyes. One man had built her a life. The other had branded her soul.  
What choice did she have—when either path meant losing a part of herself?

She sighed, long and aching, as if exhaling years of restraint. Something had changed. Irrevocably.

---

Her phone buzzed.  
**Quan:**  
*Can you meet tonight? I won’t ask for forgiveness. I just want us to be honest. Whether we end this or not—I want to be the one who respects you most.*

She didn’t reply. Just sat there, staring at the screen as evening seeped through the window.

A second message lit up:  
*I booked our old spot. If you don’t come… I’ll still wait.*

---

The café was tucked away like always—quiet, intimate. Quan sat waiting, fingers loosely spinning a cold teacup. When she walked in, his eyes lifted—no shame, no demand. Just a softness she remembered too well.

They spoke slowly. No apologies. No pretending. Just stories. Echoes. Wounds shared between sips.

> You were my dream… every damn day I was young.  
> And you were the one I let go of—not because I stopped loving you, but because I didn’t know how to fight.

As the place emptied, Quan leaned in:  
> I don’t want to undo the life you’ve built. I just want to be there… if you ever need me.  
> Come by tonight, if you want. I’d like you to see what my life became after you walked out of it.

She didn’t speak. Just nodded—barely.

---

His apartment was cleaner than she expected. Sparse, but warm. In one corner, an old photo frame held their college class picture. Her smile, frozen in time, made her heart ache.

This—was the surprise. A space that hadn’t forgotten her. A life that still kept her on its shelves.

Quan poured wine. Music played—their song. The one they’d used to study to, laugh to, fall asleep with in her dorm room.

She closed her eyes. Let it wash over her.

They sat side by side. Not touching. But close enough for their breaths to brush.

> I know I shouldn’t… but I want to understand what this is becoming.  
> I don’t want to steal you. I want you to choose—because you want to.

Night deepened. And Ha Anh didn’t leave.  
She stayed. In silence. In memory. In the pull of something far bigger than either of them.

He didn’t speak. Just gently took her hand.  
Then, wordlessly, pulled her into an embrace so soft it made her tremble.

And in that moment, when their lips met again… she stopped fighting.  
She let go.
