# Chapter 13: The Final Offering

📖 **Teaser**: The final climax of longing, guilt, and surrender. When there’s nothing left to hide, the body speaks all.

---

The door clicked shut.  
Without a word, Ha Anh dropped to her knees.  
She didn’t look at Quan. Her eyes stayed lowered, hands pressing to the wooden floor. Her fingers reached for his belt, slowly undoing each buckle, each button, as if unwrapping something sacred.

Her hands trembled. Her lips parted—soft, hesitant, then opened fully. She said nothing. The room filled only with the quiet sound of breath, and the wet hush of anticipation.

Quan stood frozen, his breath catching.  
And then… her tongue touched him.  
His eyes closed.

She licked slowly, then took him in—deeper, inch by inch. Not out of guilt. Not from pressure. But as if… this was the only gift she had left to offer.

> “I didn’t give you my first time in college… So now, I give you this. One final, complete offering.”

Quan groaned, his hand finding her hair—gripping, then letting go. He didn’t dare guide her. But she needed no guidance.

She moved with aching devotion, her throat welcoming every inch. Her lips pressed flush to his base. She stayed like that. Breathing through her nose. Feeling him throb inside her.

She wanted to remember every pulse. Every tremble.

When he finally released, she swallowed everything—without flinching, without looking away. As if this act had long been hers to perform.

She looked up.  
Her eyes shimmered.  
> “I’m ruined now, aren’t I?”

Quan pulled her up without a word.  
He kissed her.  
Led her to the bedroom.  
And laid her down like someone who’d lost her… and found her again all at once.

---

In the half-lit room, Ha Anh straddled him—facing away.  
She guided him in with quiet boldness. Her back arched, her hands braced on his thighs.

The first motion was slow.  
Then another.  
Then deeper.

Her breath hitched, and she began to ride—gently at first, then with growing rhythm, as if chasing something just out of reach.

Her hair fell down her back like a curtain of black silk. Each time she moved, her thighs clenched, her hips rolled with aching precision.

Quan watched in silence—his hands holding her waist, then sliding up to her shoulders, then tracing the sweat along her spine.

She was no longer the Ha Anh of hesitation.  
She rode like a woman possessed—lost in sensation, in memory, in some silent vow to lose herself just once.

When Quan groaned, she clenched tighter.  
When he tried to flip her over, she pressed him down.

> “No,” she whispered, breathless. “Stay there… I want to see you when you break.”

He broke.  
They both did.  
In the end, they lay tangled, breathless.  
Not talking. Just listening to the thunder outside and the storm within.

---

The shower steamed.  
Ha Anh stood beneath the water, eyes closed, fingers tracing her lips.

Quan entered behind her—warm, silent.  
His hands ran along her waist, down to her hips. He turned her slightly, lifting her thigh onto the low edge of the tub.

She gasped.  
He pressed in from behind—slow, firm. Her hands braced against the wall. Her breath came in soft cries.

The sound of water mixed with skin and sighs.  
She moaned as his thrusts deepened, his chest pressed to her back.

> “You and your husband…” he growled near her ear. “Who makes you feel more alive?”

Her lips parted.  
But no answer came.  
Only the trembling of her legs.  
Only the soft slap of wet skin.  
Only the echo of her heart, breaking—and burning—all over again.
