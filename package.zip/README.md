// Mock content for README.md
