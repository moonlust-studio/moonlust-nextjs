declare module '@/next-i18next.config' {
  const config: any;
  export default config;
}
