Chương 9: Mùi Vị Mới Của Cám Dỗ
Buổi sáng hôm sau, ánh nắng xiên nhẹ qua rèm cửa, vàng nhạt như dư âm của đêm trước còn sót lại. Hà Anh mở mắt – trần trụi, tê dại và rối loạn. Có lẽ đã rất lâu rồi, cô chưa từng có một giấc ngủ sâu đến vậy – không mộng mị, không trằn trọc. Chỉ còn hơi ấm vương trên ga giường, và mùi da thịt quen thuộc len lỏi giữa những nếp gối nhàu.
Cô khẽ xoay người – rồi khựng lại. Cơn tê âm ỉ giữa hai đùi khiến toàn thân cô co rút một cách vô thức. Mỗi lần cử động, từng thớ cơ như nhói lên âm ỉ.
Trên gối bên cạnh là một mảnh giấy nhỏ, nét chữ đậm – quen thuộc:
"Em đẹp nhất khi không che giấu điều mình khao khát."
"Anh biết... mình đang đi vào vùng cấm. Nhưng đêm qua, khi nhìn em khóc trong tay anh, anh không thể quay lưng được nữa."
"Anh chưa từng làm điều gì với người đã có gia đình. Nhưng với em, mọi nguyên tắc đều sụp đổ."
"Anh không về đây để làm em rối bời. Anh về… vì không chịu nổi khi tưởng tượng em ở gần, mà không thể chạm vào."
– Quân.
Hà Anh siết tờ giấy, nhắm mắt lại. Mỗi dòng chữ như một giọt nước nặng nề, thấm sâu vào lòng.
Cô không hối hận. Nhưng đâu đó… là cảm giác như vừa đánh mất một điều gì đó vượt xa khái niệm đạo đức – một thứ định danh bản thân cô lâu nay.
Cô khẽ bật cười – vừa ngượng, vừa... thỏa mãn.
“Không rõ là bao nhiêu lần… mà sáng ra, cả thân dưới như muốn buông rời…”
“Và đúng là… Quân khác xa chồng mình thật.”
Cô lặng lẽ trở về căn hộ, ngâm mình dưới vòi sen thật lâu. Nước mát dội qua làn da mỏi mệt, nhưng chẳng thể gột rửa lớp ám ảnh. Mỗi giọt nước trượt xuống da như lặp lại từng nhịp đẩy, từng âm thanh khẽ rên, từng ánh mắt say mê mà cô đã để bản thân lạc vào đêm qua.
Trước gương, cô nhìn mình thật lâu – ánh mắt ngập ngừng, như soi thấy một điều gì đó đã không thể quay lại.
Một phần trong cô dậy sóng – không phải vì khoái cảm, mà vì tội lỗi. Bóng dáng người chồng hiện lên giữa làn hơi nước – người đàn ông tử tế, điềm đạm, chưa từng nặng lời hay rời bỏ cô giữa bất kỳ sóng gió nào. Anh là người âm thầm gánh vác, hy sinh cả tuổi trẻ chỉ để mẹ con cô được an yên.
Cô nhớ những đêm anh thức trắng chăm con ốm, những bữa cơm anh gọi về chỉ vì biết cô mệt. Cô nhớ ánh mắt anh hôm tiễn cô ra sân bay – đầy yêu thương và niềm tin.
Chính vì vậy… cô giận cuộc đời. Tại sao lại để Quân quay trở lại? Tại sao vào đúng thời điểm cô trống trải nhất, yếu lòng nhất, khao khát một cái ôm đủ lâu để xoa dịu mọi vỡ vụn trong lòng?
Nếu ngày đó – cô và Quân đủ dũng khí vượt qua mọi rào cản, liệu hôm nay có còn phải sống trong cảnh trái ngang thế này? Liệu cô có phải lén lút trong day dứt, thay vì được yêu một cách đàng hoàng?
Cô cắn môi. Đôi mắt hoe đỏ. Trái tim như bị xé đôi: một bên là người chồng đã cùng cô gầy dựng mái ấm, một bên là người từng khiến tuổi trẻ cô bừng cháy – và nay, chỉ cần một cái nhìn cũng đủ khiến cô run rẩy.
Cô phải làm sao… khi lựa chọn nào cũng như đánh mất một phần chính mình?
Hà Anh thở dài – dài như một tiếng gió mùa chuyển tiết. Và cô biết, từ đây, mọi thứ đã không thể quay lại như trước.

Điện thoại rung nhẹ trên mặt bàn. Một dòng tin nhắn hiện lên – từ Quân:
“Tối nay em có thể ra ngoài một chút không?”
“Anh muốn gặp em, nói chuyện thật sự nghiêm túc. Không phải để xin lỗi, càng không phải để biện minh.”
“Anh nghĩ… nếu đã đi xa đến mức này, thì ít nhất cũng nên thẳng thắn với nhau. Dù kết thúc hay tiếp tục – anh vẫn muốn là người tôn trọng em nhất.”
Hà Anh đọc đi đọc lại từng chữ. Không có lời nào dư thừa, chẳng một chút ủy mị. Nhưng trong từng khoảng ngắt… là sự chân thành lặng lẽ – như cách anh vẫn ôm cô mỗi khi cô run lên vì yếu lòng.
Cô chưa trả lời. Chỉ lặng nhìn khoảng trời chiều sau ô cửa sổ – nơi gió đang lay nhẹ rèm cửa. Tim vẫn chưa có lời, nhưng tay cô đã siết chặt lấy chiếc điện thoại.
Vài phút sau, tin nhắn thứ hai đến:
“Anh đặt bàn ở chỗ cũ. Nếu em không đến… anh vẫn sẽ đợi.”

Quán cà phê cũ nằm nép mình trong một con phố nhỏ – nơi ngày xưa họ từng lặng lẽ nhìn nhau, rồi lặng lẽ bước qua nhau. Quân đã ngồi đó từ sớm, tay khẽ xoay tách trà đã nguội. Khi Hà Anh bước vào, ánh mắt anh ngước lên – không trách móc, không gượng gạo. Chỉ có ánh sáng dịu và một nụ cười rất nhẹ.
Cuộc trò chuyện bắt đầu chậm rãi. Không ai xin lỗi, cũng chẳng ai đổ lỗi. Họ chỉ nói – về những điều từng có, những điều đã lỡ, và cả những điều… vẫn còn âm ỉ trong tim.
"Em từng là giấc mơ của anh... suốt những năm tháng tuổi trẻ."
"Và anh từng là người em muốn giữ, nhưng không đủ dũng khí để đấu tranh."
Khi quán vắng dần, Quân khẽ nói:
"Anh biết, giờ nói gì cũng không thay đổi được hiện tại. Nhưng thật lòng... anh cũng không muốn thay đổi gì cả. Anh chỉ muốn được bên em – bất cứ khi nào em cần, bất cứ khi nào em muốn. Chỉ cần vậy thôi, anh đã thấy đủ rồi."
"Tối nay... nếu em không vội, về căn hộ anh một lát nhé. Anh có một bất ngờ nhỏ muốn dành cho em. Và... để em biết, anh đã sống thế nào – kể từ ngày không còn em bên cạnh."
Hà Anh không trả lời. Nhưng ánh nhìn dịu xuống – rồi khẽ gật đầu.

Căn hộ của Quân đơn giản, ấm cúng – gọn gàng đến bất ngờ. Trên kệ sách, ở một góc nhỏ, là khung ảnh cũ: bức hình lớp đại học, nơi Hà Anh đang cười rạng rỡ giữa nhóm bạn. Cô nghẹn lại.
Điều bất ngờ mà anh nhắc đến – chính là không gian sống ấy vẫn đầy ắp hình ảnh của họ thuở sinh viên. Những khoảnh khắc tưởng như bị chôn vùi dưới lớp bụi thời gian, nay bỗng ùa về, lấp lánh như vừa mới hôm qua.
Cô bước chậm quanh căn phòng, ánh mắt khẽ chạm vào từng vật thể. Quân không nói gì, chỉ lặng lẽ rót hai ly vang đỏ.
Anh với tay bật nhẹ chiếc loa trên kệ. Một bản nhạc cũ vang lên – chính là bài hát mà cả hai từng nghe khi còn ngồi chung thư viện, hay dạo bước giữa những con phố Hà Nội rợp lá.
Giai điệu dịu dàng như luồn hơi ấm len lỏi vào tim. Mỗi âm thanh như nhấc bổng ký ức. Hà Anh nhắm mắt – tim đập lệch một nhịp.
Họ ngồi bên nhau – không gần, cũng chẳng xa. Chỉ đủ để hơi thở lặng lẽ chạm nhau trong yên lặng.
“Em nghĩ... mình đang bắt đầu lại một điều gì đó không nên. Nhưng trái tim thì lại muốn hiểu nó nhiều hơn…”
“Anh chưa từng muốn cướp em khỏi ai cả. Anh chỉ muốn… nếu em buông, thì là vì chính em chọn.”
Đêm xuống chậm. Và Hà Anh – không rời đi.
Cô ở lại. Trong một căn phòng ngập tràn dư âm ký ức. Không gian yên ắng, ánh đèn vàng dịu, ly vang sóng sánh trong tay… Tất cả khiến tim cô bồi hồi. Cảm xúc dội về như sóng – mềm, dai dẳng, và bất tận.
Cô bối rối. Có phần lo sợ. Vì cô biết – nếu không vượt qua được đêm nay, thì có lẽ chẳng bao giờ cô còn vượt qua được nữa.
Quân dường như hiểu điều đó. Anh không nói gì. Chỉ nắm lấy tay cô – ánh mắt dịu dàng nhưng cháy âm ỉ. Rồi nhẹ nhàng kéo cô về phía mình – một vòng tay không gượng ép, không vội vàng. Chỉ đủ để hơi thở hòa vào nhau, trong khoảng cách không còn phòng bị.
Nụ hôn đến – chậm, ấm, và ướt. Như thể đã được ủ từ bao năm tháng.
Hà Anh không chống cự. Cô siết anh thật chặt – như muốn nói: “Em biết mình đang sai… nhưng trái tim này không thể giả vờ nữa.”
Và khi đôi môi họ chạm nhau – là khoảnh khắc cô thừa nhận: mình đã chấp nhận.