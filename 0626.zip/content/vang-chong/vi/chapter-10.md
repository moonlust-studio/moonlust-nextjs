# Chương 10: Đêm Không Còn Lối Thoát

Không gian vẫn ấm vàng dưới ánh đèn mờ. Mùi rượu vang quyện trong không khí làm tim người ta dễ chênh choáng. Giai điệu nhạc cũ vẫn đang tròn trình trên loa, như kích hoạt lại những ký ức đang nổi dậy trong tim.
Hà Anh ngồi bên Quân, đôi mắt long lanh như ánh đèn phản chiếu lên mặt hồ khuya. Cô hơi nghiêng đầu, nép vào vai anh. Từng nhịp thở của Quân phả nhẹ bên tóc mai khiến sống lưng cô rùng mình.
Bàn tay anh nhẹ nhàng nâng cằm cô lên, rồi cúi xuống, trao một nụ hôn mềm như tan giữa hơi thở. Nụ hôn ấy không vồ vập mà miên man, như một bản nhạc jazz chậm rãi ngân trong đêm. Tay Quân đan vào tóc cô, luồn nhẹ xuống cổ, rồi lần theo sống lưng như đang vẽ lại một đường ký ức.
Cô cũng đưa tay ôm lấy anh, kéo sát về phía mình, hai cơ thể áp sát như chưa từng có khoảng cách. Hơi thở giao nhau, từng cái chạm đều đong đầy kỷ niệm, từng chuyển động là một lời thì thầm lặng lẽ rằng: “Em nhớ anh đã bao năm trời.Tình đầu khó phai là thật Quân ạ!”
Cả hai không nói gì, chỉ có ánh mắt lặng im, như một thỏa thuận từ những năm tháng cũ. Khi bàn tay Quân mở từng nút áo, cô khẽ nhắm mắt, để mặc cơ thể tan chảy trong nhịp cảm xúc.
Khi bên trong phòng đã chỉ còn ánh sáng vàng nhẹ, khi cánh áo ngực của Hà Anh được cởi bung, khi lần da chạm da...bàn tay anh di chuyển khắp vùng ngực căng tròn đầy sức sống của cô, Tim cô nóng bừng, những sợi thần kinh dưới da căng lên, khiến vòng ngực như ngậm đầy ánh lửa – căng tròn, săn lại, và khát khao được chạm đến.
Cô nhắm mắt. Cảm giác tội lỗi và khao khát quấn lấy nhau, như hai dòng nước xoắn xuýt không lối thoát.
Anh đặt cô xuống sofa, chậm rãi và dịu dàng, như đang nâng niu một điều gì đó vừa thiêng liêng vừa nguy hiểm. Mỗi nụ hôn là một cú đẩy nhẹ khiến cô trôi xa dần khỏi lý trí.
Áo lót rơi xuống sàn. Đùi quấn vào hông. Quân lần tay xuống, chạm vào nơi đang nóng ẩm nhất trên cơ thể cô.
— Em... ướt quá rồi...
Hà Anh rên khẽ ư... và tay cô chủ động tìm đến nơi cứng nhất của Quân – vươn cao, căng cứng, như một đỉnh núi chực trào nham thạch – chỉ chờ cô chạm vào là bùng nổ. Cả hai như trôi vào một cõi khác, nơi chỉ còn cảm giác quên đi  tất cả chỉ còn tiếng thở dốc và tiếng nhạc cũ rỉ rả như mưa rơi qua kẽ tim.
Quân tách hai đùi cô ra, hôn xuống dưới rốn, rồi dừng lại ở đó, ánh mắt ngước lên tìm kiếm sự chấp thuận. Những sợi nhung thưa mềm phía dưới bụng cô khẽ rung lên theo hơi thở của anh – mảnh mai, mờ ảo như một tán cỏ mỏng trong sương sớm, càng làm nổi bật nơi đang ẩm nóng ngay trung tâm. Hà Anh thở gấp, khẽ gật đầu. Và rồi lưỡi anh trượt vào, chậm rãi, ấm và mềm, như một dòng suối nóng nhỏ chảy qua từng thớ thịt đang khao khát.
Cô cong lưng lên, tay bấu vào thành ghế, từng tiếng rên bật ra từ cổ họng như không thể kiềm lại. Những cú liếm sâu và đều đặn của Quân khiến cô nghẹn ngào, ướt đẫm và gần như không còn lý trí.
Khi anh nhổm người lên, kéo bao cao su từ ngăn kéo bàn bên cạnh, Hà Anh nắm nhẹ lấy tay anh, ánh mắt vừa ngượng ngùng vừa thiết tha:
— Anh... đừng dùng. Em muốn cảm nhận anh... thật nhất.
Quân sững người trong một thoáng. Rồi không nói gì, anh đặt chiếc bao trở lại ngăn kéo, tiếng soạt nhẹ vang lên trong không gian tĩnh – một âm thanh nhỏ mà vang như dấu ấn cho sự buông xuôi, nghiêng người cúi xuống, hôn nhẹ lên trán cô như một lời hứa. Ánh mắt họ gặp nhau – ướt, rực và cam chịu.
Cô đẩy nhẹ anh ngồi xuống sofa, ánh mắt vừa ngại ngùng vừa dạn dĩ. Tiếng nhạc lùi xa dần như nhường chỗ cho hơi thở dồn dập dâng lên. Mỗi tiếng động nhỏ trong căn phòng bỗng trở nên rõ rệt – như thể thời gian cũng đang nín thở theo từng chuyển động của họ. Rồi cô quỳ xuống sàn, giữa hai chân anh, ngước nhìn anh bằng ánh nhìn ướt mềm, vừa e dè vừa khao khát.
Đôi môi cô chạm nhẹ lên bụng anh, rồi lần xuống thấp hơn. Hà Anh hôn lên phần thân đã căng cứng như chực vỡ tung, đôi tay khẽ vuốt ve đầy trân trọng – như đang chạm vào một phần ký ức thiêng liêng vừa hồi sinh.
Quân thở gấp, siết chặt tay vào thành ghế. Cô dùng miệng, chậm rãi, mềm mại – như đang thì thầm một lời xin lỗi, một lời bù đắp cho những năm tháng lỡ làng. Tiếng nhóp nhép khẽ vang lên, ướt mềm, rồi nghèn nghẹn khi phần đầu cậu nhỏ chạm vào sâu tận cổ họng – khiến cô khẽ rùng mình nhưng không hề lùi bước.
Giọng Quân đứt quãng: — Em biết không… anh đã tưởng tượng khoảnh khắc này… suốt bao năm…
Cô chỉ nhìn anh, ánh mắt long lanh, rồi đáp bằng cái liếm nhẹ đầu lưỡi – như thay cho câu: “Em cũng vậy…”
Khi Quân rên nhẹ, cô mới dừng lại, lau khóe môi, rồi đứng dậy trèo lên đùi anh. Hai cơ thể quấn chặt lấy nhau. Hà Anh điều chỉnh tư thế, rồi chủ động ngồi xuống, để anh tiến vào thật sâu.
Tiếng da thịt va chạm vang lên đều đặn, cô nhắm nghiền mắt, miệng khẽ rên từng nhịp, đôi tay bám lấy vai anh như bấu víu vào khoảnh khắc ngắn ngủi của lãng quên.
Thế giới như thu lại còn một căn phòng, một nhịp đẩy, một tiếng thở – và một lần trọn vẹn cho tình đầu chưa từng được gọi tên.
Tư thế đầu tiên – truyền thống. Quân nằm giữa hai chân cô, đỡ gáy cô bằng một tay và nhìn vào mắt cô khi tiến vào. Cảm giác bị lấp đầy khiến Hà Anh rướn người lên trong vô thức, miệng khẽ bật lên một tiếng rên nghẹn.
Đúng lúc ấy, điện thoại rung lên. Tên chồng hiện lên.
Hà Anh nuốt nghẹn trong cổ. Nhưng lần này – cô không lờ đi. Ở đầu dây bên kia, cô nghe thấy cả tiếng tàu chạy ngang qua, tiếng người chào hỏi mờ xa, tiếng gió luồn nhẹ qua ống nghe – tất cả khiến tình cảnh của cô càng thêm nghẹt thở.
Cô với tay lấy điện thoại, nhấn nút nghe – bàn tay kia vẫn đặt trên vai Quân, còn thân dưới thì không ngừng đón nhận những nhịp thúc sâu đầy mãnh liệt. Giọng cô run nhẹ:
— A… alo… em nghe đây…ự...
Giọng chồng từ đầu dây bên kia vang lên, ấm áp và quen thuộc: — Em yêu, anh báo một tin mừng… Tuần tới anh về phép! Và anh đưa Tony – là bạn của anh bên này. Tony về tìm cơ hội phát triển ngành ngôn ngữ và tâm lý học....
Hà Anh cắn môi, cố nuốt tiếng rên. Cô khẽ đáp, giọng thều thào:
— V… vâng… em… nhớ…ự...
Một cú thúc sâu khiến cô gần như bật tiếng,cô muốn gia hiệu cho quân dựng lại 1 chút nhưng quân không hiểu ý lại càng mạnh hơn,ư.... cô vội che miệng, khẽ thì thào tiếp:
— Xin lỗi… hình như… điện thoại… sắp hết pin…
Cô tắt máy. Rồi nằm thở dốc. Đôi mắt ngân ngấn – vừa vì khoái cảm chưa dứt, vừa vì biết rằng… mọi thứ từ nay sẽ không còn yên bình nữa.
Hà Anh siết chặt eo khóa chân cố đằng sau lưng quân, buông điện thoại xuống mặt bàn, Bàn tay Quân lại kéo cô sát vào lòng, môi anh lướt dọc xương quai xanh, rồi hạ dần xuống.
Trái tim cô đập loạn. Nhưng phần thân dưới thì vẫn đang bị chiếm lĩnh hoàn toàn. Anh vẫn giữ ánh nhìn, vẫn đều đặn đẩy sâu vào bên trong cô, như thể toàn bộ thế giới chỉ còn hai người.
Cô khép mắt, thở dốc ngược ưỡn lên cao sau mỗi cú dập. Trong lúc chồng báo tin trở về, thì cô lại đang nằm trần trụi dưới một người đàn ông khác. Vừa đau, vừa rạo rực, vừa không muốn dừng lại.
Miệng cô khẽ bật lên một âm thanh đầy bản năng – không thành tiếng, không rõ lời, chỉ là một chuỗi âm ướt mềm run rẩy: “Ư… a… Quân… sâu quá… mạnh nữa đi… đừng dừng lại…”
— Nhìn anh đi… anh muốn thấy em ở ngay đây, lúc này, hoàn toàn thuộc về anh.
Mỗi cú thúc là một nhịp đập. Quân gằn giọng sát tai cô: — Mỗi lần vào em… anh thấy như đang lấy lại tất cả những năm tháng đã mất.
Ngực cô rung lên theo từng chuyển động. Tiếng da thịt chạm nhau dội vào không gian, hòa cùng tiếng nhạc, tiếng rên khẽ, tiếng thở dốc – tất cả như bản hoà tấu bí mật của dục vọng và tình yêu.
Anh xoay người cô lại – tư thế úp thìa. Từ phía sau, anh thì thầm: — Anh muốn chạm vào nơi sâu nhất của em…
Bàn tay anh luồn ra trước, xoa nhẹ giữa hai đùi, còn phần thân dưới vẫn đều đặn ra vào sâu dần, sâu dần...
Mỗi lần rút ra gần hết rồi đẩy vào lại như muốn phá tan mọi phòng bị trong cô. Hà Anh không còn biết mình đang rên hay khóc – chỉ thấy người rung lên từng đợt như sóng vỗ bờ cát yếu mềm.
— Em sắp… — Cùng anh nhé…
Một cú thúc sâu, mạnh, gằn lại. Cô run bắn, toàn thân siết chặt lấy anh như không muốn rời.
Anh rút ra kịp lúc, bắn lên bụng cô. Tiếng thở hổn hển hòa vào nhịp tim dồn dập. Nệm ghế lún xuống một nhịp, như chính không gian cũng vừa đạt cực điểm cùng họ. Những giọt nóng hổi thấm vào làn da mềm, rồi chảy thành vệt mảnh dọc theo eo xuống đùi – như những sợi lụa ướt phủ lên tấm thân đang rã rời sau hoan lạc. Hà Anh thở dốc, tay che mắt, ngực phập phồng – không nói nên lời. Nhưng rồi cô khẽ vươn người xuống, như muốn ngập lại trong anh, để cảm nhận trọn vẹn dư vị yêu thương còn đọng lại trên da thịt – không vội vàng, không ngượng ngùng, chỉ là một khát khao lặng lẽ được nếm trọn dư âm nóng hổi ấy lần nữa.Hai người ôm chặt nhau môi họ cuộn vào nhau đầy ướt át và hành phúc...
Dù không nói thành lời, nhưng trong lòng cô đã biết – ranh giới ấy đã bị xóa nhòa hoàn toàn, và cô đã chấp nhận đi cùng Quân vào vùng cấm không còn lối về.
Đêm hôm đó cũng như đêm trước họ quấn vào nhau làm tình cho tới sáng mà không mệt mỏi, lần nào cũng mãnh liệt và cuồng nhiệt, Hà Anh như được sống với con  người thực của mình...
Sau đêm hôm đó ngoài những lúc bận rộn với công việc hay chăm con ra, Hà Anh và Quân lại cuốn lấy nhau, khi thì ở nhà Quân Khi thì ở những love hotel trong trung tâm thành phố, Có những hôm ban ngày họ vụng trộm với nhau buổi trưa tranh thủ lúc nghỉ trưa trong 1 khách sạn nào đó nhưng tối về họ vẫn  quan hệ cả đêm....
Cuộc gọi hôm đó như một lời báo trước – ngày mai, chồng Hà Anh sẽ về nghỉ phép...
