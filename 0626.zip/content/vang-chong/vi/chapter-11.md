# Chương 11: Ngày Anh Trở Lại


Đêm trước ngày chồng về, Hà Anh và Quân biết họ sẽ phải xa nhau ít nhất hai tuần. Anh có chuyến công tác bất ngờ vào sáng sớm, còn cô phải chuẩn bị đón chồng trở lại sau gần hai năm xa cách. Họ không nói nhiều, chỉ lặng lẽ nhìn nhau trong ánh đèn ngủ mờ hắt lên trần nhà, như đang đếm ngược từng nhịp thời gian còn lại.

Cô ngồi trên đùi anh, để ánh sáng mờ chiếu nghiêng lên làn da trắng như sứ. Căn phòng yên tĩnh, chỉ còn tiếng quạt trần quay đều đều trên trần, xen lẫn âm thanh va chạm nhẹ của vải vóc và hơi thở gấp gáp. Hà Anh cúi xuống, tay run rẩy chạm vào nơi đang căng cứng và nóng hổi giữa hai chân anh. Cô vuốt dọc theo chiều dài ấy như lần đầu khám phá, rồi từ từ dẫn anh vào trong mình — chậm, sâu, và đầy chủ ý. Như thể muốn khắc lại cảm giác này, như một lời tạm biệt thầm lặng mà thân xác gửi đến nhau.

Quân vòng tay giữ lấy eo cô, dập nhịp đều đặn và siết chặt như muốn giữ lấy thời khắc cuối cùng. Không còn lời yêu, không còn ranh giới – chỉ còn tiếng da thịt chạm nhau rì rầm trong căn phòng ngập mùi quyến luyến, xen lẫn tiếng thở gấp, tiếng giường khẽ kêu cọt kẹt mỗi khi nhịp chuyển động mạnh hơn.

Hà Anh cúi xuống, hôn lên vai anh, thì thầm bên tai:
— Em sẽ nhớ… từng giây của đêm nay.

Quân không trả lời. Anh lật người cô xuống giường, ghì lấy, và dập từng cú sâu như một lời chia tay không nói thành lời. Khi họ cùng lên đỉnh, cả hai như cùng rơi vào khoảng trống – nơi không có tương lai, không có quá khứ – chỉ còn hiện tại đầy say đắm và đau đớn.

Đến phút cuối cùng, Hà Anh khẽ đẩy anh ra, ánh mắt chao nghiêng đầy ái ngại. Cô không để anh tràn vào trong, như những lần trước. Cảm giác mơ hồ về sáng mai, về cái nhìn từ người đàn ông đã từng là tất cả, khiến cô khẽ run. Cô chỉ rướn người, đón lấy dòng nóng bỏng đó trên gương mặt mình, rồi cúi xuống mút khẽ, như giữ lại dư âm – bằng tất cả tiếc nuối và bản năng.

Khi cô lặng lẽ nằm nghiêng trong vòng tay anh, mồ hôi lấm tấm trên sống lưng, ánh sáng từ đèn ngủ vàng nhạt vẫn lặng lẽ chiếu lên trần. Gió quạt lùa nhẹ qua những sợi tóc bết mồ hôi, khiến lòng cô mát như vừa bước qua một cơn bão... và biết mình vẫn còn sống.

Quân hôn nhẹ lên gáy cô, thì thầm:
— Đêm nay… em là của anh. Nhưng ngày mai… em vẫn là em – mẹ, vợ, và… người phụ nữ từng thuộc về một người đàn ông khác.

Hà Anh không trả lời. Cô chỉ siết tay anh thật chặt, như níu lấy khoảnh khắc ngắn ngủi ấy. Trong lòng cô, đã không còn ranh giới – chỉ còn dư âm – mặn, nóng, và thấm tận sâu… nơi không lời nào chạm tới được.

Một ý nghĩ thoáng qua trong cô, nhức nhối và dịu dàng: “Ngày đó… em không dám trao cái ngàn vàng cho anh. Thì hôm nay, em muốn cho tất cả. Cả phần sâu nhất chưa ai từng chạm đến… coi như một lần trọn vẹn sau cùng.”

Cuối tháng Sáu, Hà Nội oi nồng và bụi bặm, như thể cả thành phố đang giữ lại mọi bí mật của mùa hạ trong lớp không khí dày đặc. Hà Anh đứng trước gương, chỉnh lại cổ áo sơ mi trắng. Ánh sáng sáng sớm hắt vào qua khe cửa, rọi lên gương mặt cô – gầy hơn, nhưng ánh mắt lại sâu và lặng hơn bao giờ hết.

Sáng nay, chồng cô trở về.

Chiếc vali màu xám đã được đặt sẵn ở cửa. Đêm qua, cô gần như không ngủ. Không phải vì sợ hãi, mà vì chính cô cũng không biết phải giấu giếm điều gì, và giấu như thế nào. Mọi dấu vết đã được xóa sạch – ga giường thay mới, nước hoa cũ bị bỏ đi, quần áo sắp xếp lại… Nhưng còn cảm giác? Còn mùi da thịt Quân vẫn như vương vất ở đâu đó, quanh ngực, dưới bụng, trong ánh mắt cô soi vào gương?

Tiếng còi xe ngoài ngõ làm cô giật mình. Cô bước nhanh ra cửa, mở cổng. Và người đàn ông ấy – người chồng đã xa nhà gần hai năm – bước vào, kéo theo làn hơi nắng lẫn mùi mồ hôi của những chuyến bay dài. Anh ôm lấy cô như ôm một điều gì đó thân quen và dễ vỡ. Hà Anh cũng siết nhẹ lấy anh, như một phản xạ… nhưng không biết tim mình đang đập vì điều gì.

“Anh về rồi đây…” – anh nói, giọng trầm và mệt. Nhưng trong ánh mắt có gì đó chưa kịp chạm tới.

Đứng phía sau anh là một người đàn ông ngoại quốc. Da ngăm, cao lớn, mái tóc xoăn nhẹ, kính mát kẹp ở cổ áo sơ mi xanh. Anh ta gật đầu chào cô:

— Xin chào. Tôi là Tomy – bạn cùng về Việt Nam với Đức Anh. Rất vui được gặp chị.

Cô khẽ gật đầu đáp lễ, mỉm cười nhẹ. Chỉ là một người bạn đi cùng – vậy thôi.
