# Chapter 11 – The Day He Returned

📖 **Teaser:** When guilt begins to taste like desire, even silence burns.

---

The night before her husband’s return, Ha Anh and Quan knew they’d be apart for at least two weeks. He had an unexpected business trip in the morning, and she needed to prepare for her husband’s arrival after nearly two years away. They didn’t speak much—just lay quietly under the dim glow of the bedside lamp, eyes fixed on the ceiling as if counting down the seconds they had left.

She straddled him, letting the soft light skim her porcelain skin. The room was still, filled only with the whir of the ceiling fan and the soft rustling of fabric and quickening breaths. Ha Anh lowered herself, her trembling fingers reaching between his legs, gently wrapping around the heat pulsing there. She stroked along its length as though discovering it for the first time, then slowly guided him inside—deep, deliberate, as if trying to etch the sensation into memory. A silent farewell, written in the language of skin.

Quan wrapped his arms around her waist, moving in rhythm, gripping tighter as if to capture this final moment. No words of love. No lines drawn. Just the sound of bodies meeting, echoing through a room scented with longing, laced with breathless sighs and the faint creak of a bed shifting with each thrust.

She leaned down, kissed his shoulder, whispered in his ear: — I’ll remember… every second of tonight.

He didn’t respond. He rolled her beneath him, held her down, and drove into her with the weight of an unspoken goodbye. When they climaxed, it was as if they tumbled into a void—no future, no past—only the now, wrapped in passion and pain.

In the final seconds, Ha Anh gently pushed him back, her eyes tilting with quiet hesitation. She didn’t let him finish inside her, not like before. The looming presence of the morning—of a man who once meant everything—made her tremble. Instead, she raised herself and caught his heat on her face, softly suckling the last of it, as if clinging to the taste with every drop of instinct and regret.

Later, lying curled in his arms, sweat beading along her spine, the amber glow from the lamp cast their shadows upward. The fan stirred the damp strands of her hair, cooling her like the tailwind of a storm she’d survived… barely.

He kissed the nape of her neck, murmuring: — Tonight… you’re mine. But tomorrow… you’ll be you again. A mother. A wife. A woman who once belonged to another man.

She said nothing. Just held his hand tighter, trying to freeze the moment. There were no boundaries anymore—only echoes. Salty. Hot. Deep. In places no word could ever reach.

A thought flickered inside her, aching and tender: “That day… I couldn’t give you my innocence. So tonight, I gave you everything. Even the part no one else had touched… a final, complete surrender.”

---

Late June in Hanoi was thick with heat and dust, as if the whole city had bottled up summer’s secrets in its sweltering air. Ha Anh stood in front of the mirror, straightening the collar of her white blouse. Morning light filtered in through the blinds, highlighting a thinner face, deeper eyes.

Today, her husband was coming home.

The gray suitcase sat ready by the door. She had barely slept, not out of fear—but because she no longer knew what needed hiding… or how to hide it. All traces had been erased—new bedsheets, discarded perfume, rearranged clothes. But sensations? The scent of Quan still clung somewhere—around her chest, under her belly, in the gaze staring back at her from the mirror.

A car horn startled her. She walked quickly to the gate. And there he was—the husband who had been gone nearly two years—stepping in, wrapped in sun and sweat and the fatigue of long-haul flights. He embraced her like one clutches something familiar and fragile. She held him too, by reflex… but her heart beat uncertainly.

“I’m home,” he said, his voice low and tired. Yet his eyes hadn’t quite found her.

Behind him stood a foreign man. Dark-skinned, tall, lightly curled hair, sunglasses tucked into the collar of a blue shirt. He nodded politely:

— Hello. I’m Tony—traveling with Andrew back to Vietnam. Nice to meet you.

She nodded with a soft smile. Just a guest, that’s all.

That evening, after the welcome dinner, Tony was invited to stay a few days for work. They chatted lightly—weather, culture, Hanoi in summer. Ha Anh mostly listened, smiling, offering food, then quietly excusing herself, worn out from the day’s preparations.

After Tony left for the hotel, she tucked their son into bed. Only the two of them remained.

Her husband pulled her close on the couch, his arm around her shoulder. The golden glow of a table lamp softened the room, masking the invisible distance between them.

His voice was low, slightly hoarse:

— I missed you… so much. The house, your scent, even the way you scolded me before I left. I’m no good with words, but… without you, I couldn’t breathe.

She didn’t know how to respond. She smiled faintly, nodded, resting her head on his shoulder. Her heart raced… not from emotion, but anxiety. Images of Quan hadn’t faded yet.

He stood, took her hand: — It’s been too long… Let’s go upstairs.

She nodded. Every step up the stairs felt heavy with fear—fear of being found out.

In the bedroom, the only light came from the corner lamp. He pulled her into him, kissing her neck and shoulders like a starving man. She closed her eyes, letting him unbutton her blouse, his hands roaming her back, her breasts, and lower.

He panted into her ear: — You’re still so soft… still smell the same. God, I’m going crazy.

She wrapped her arms around him, each motion careful, restrained. She was scared—afraid her body still carried traces of Quan. Afraid her husband might notice.

She whispered, trying to stir longing: — Make love to me… like we were never apart… I missed you… I need you…

He lost control, lifted her to the bed, mounted her, and entered her in one swift thrust—too sudden for her to prepare. Their scents—sweat, skin, separation—mingled in the thick air. The lamp flickered, the fan spun, and the bed began to creak again… but it echoed differently than it had with Quan.

She didn’t feel pain. Nor pleasure. Just something missing. She realized… maybe her body had grown used to another kind of fullness—slower, deeper, heavier—the kind only Quan gave.

Her husband groaned: — You’re still perfect… Thank you… for waiting for me.

She arched with each thrust, trying to match his rhythm, but inside, she counted—each push bringing her closer to the end. When he tensed and spilled inside her, she tightened her thighs—not from pleasure, but to keep it from escaping too quickly.

As he collapsed beside her, breathless, she turned her face away. Her eyes stared into the dark. Her heart raced—not from lovemaking, but from the ache of knowing… she hadn’t been touched at all.
