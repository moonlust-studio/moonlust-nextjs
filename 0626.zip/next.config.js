// ✅ FILE: next.config.js – KHÔNG dùng i18n nữa!
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // ✅ static export cho Cloudflare Pages
  experimental: {
    optimizeCss: true,
    //serverActions: true,
  },
};

module.exports = nextConfig;
